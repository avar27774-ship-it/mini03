# Minions Market

A Playerok-style dark gaming marketplace where users can buy and sell game accounts, currency, skins, and items with escrow-protected deals.

## Architecture

This is a pnpm monorepo with three main packages:
- `artifacts/minions-market` — React + Vite frontend (port from `PORT` env var)
- `artifacts/api-server` — Express 5 + TypeScript ESM backend (port 8080)
- `lib/api-client-react` — Orval-generated React Query hooks from OpenAPI spec
- `lib/db` — (unused, raw SQL via pg pool in api-server instead)

## Tech Stack

**Frontend:**
- React + Vite + TypeScript
- Tailwind CSS v4 with shadcn/ui components
- wouter for routing
- TanStack React Query (v5) via generated Orval hooks
- react-hook-form + zod for forms
- Lucide React icons
- Onest font from Google Fonts

**Backend:**
- Express 5 + TypeScript ESM
- PostgreSQL via `pg` (native pool)
- bcryptjs for password hashing
- jsonwebtoken for JWT auth
- Raw SQL with queryOne/queryAll/run helpers
- DB schema auto-initialized on startup (`initSchema()`)

## Design

- Dark #0D0D0E background, #1B1B1D surface/card
- #FFD600 yellow/gold accent
- Mobile-first, max-width 480px
- Bottom navigation (Home, Catalog, +Sell, Messages, Profile)
- Burger menu slide-in with Deals, Wallet, Settings, Logout

## Pages

- `/` — Home: search, stats, category grid, featured products
- `/catalog` — Product catalog with category filters, search, sort, pagination
- `/product/:id` — Product detail with buy button and seller info
- `/profile/:id?` — User profile with listings and reviews
- `/auth` — Login/register with tabs
- `/sell` — Create a listing (auth required)
- `/deals` — Deals list with buyer/seller tabs (auth required)
- `/wallet` — Balance, deposit, withdraw, transaction history (auth required)
- `/messages` — Chat list and message threads (auth required)
- `/settings` — Edit profile and logout (auth required)

## API Routes

All routes under `/api/`:
- `/api/auth/*` — register, login, me
- `/api/products/*` — CRUD, featured, stats, favorites
- `/api/users/*` — profile, user products, update profile, favorites
- `/api/deals/*` — list, create, confirm, dispute, deliver, review
- `/api/wallet/*` — balance, transactions, deposit, withdraw
- `/api/messages/*` — chats, message threads, send
- `/api/categories` — list categories

## Auth

JWT tokens stored in localStorage, passed via `Authorization: Bearer <token>` header.
The `customFetch` in api-client-react auto-attaches the token via `setAuthTokenGetter()`.

## Commission System

Deals use 5% commission: seller receives 95% of the sale price. The buyer's balance is frozen on deal creation and released to the seller on confirmation.

## Deployment

For Railway deployment:
- Set `DATABASE_URL` and `SESSION_SECRET` (used as JWT_SECRET)
- Frontend served as static build or via Vite dev server
- API server starts with `pnpm --filter @workspace/api-server run start`
- DB schema auto-initializes on first startup
