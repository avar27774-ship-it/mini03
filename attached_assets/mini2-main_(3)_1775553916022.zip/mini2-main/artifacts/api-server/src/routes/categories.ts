import { Router } from "express";
import { queryAll } from "../lib/db";

const router = Router();

router.get("/", async (_req, res) => {
  try {
    const categories = await queryAll<Record<string, unknown>>(
      "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC"
    );
    res.json(categories.map(c => ({
      id: c.id, name: c.name, slug: c.slug, icon: c.icon, sortOrder: c.sort_order,
    })));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

export default router;
