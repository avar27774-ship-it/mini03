import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import productsRouter from "./products";
import usersRouter from "./users";
import dealsRouter from "./deals";
import walletRouter from "./wallet";
import messagesRouter from "./messages";
import categoriesRouter from "./categories";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/products", productsRouter);
router.use("/users", usersRouter);
router.use("/deals", dealsRouter);
router.use("/wallet", walletRouter);
router.use("/messages", messagesRouter);
router.use("/categories", categoriesRouter);

export default router;
