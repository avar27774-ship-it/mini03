import { Router } from "express";
import { queryOne, queryAll, run } from "../lib/db";
import { authMiddleware, type AuthRequest } from "../lib/auth";

const router = Router();
const COMMISSION = 0.05; // 5% commission

function parseDeal(d: Record<string, unknown>) {
  return {
    id: d.id,
    dealNumber: d.deal_number,
    buyerId: d.buyer_id,
    sellerId: d.seller_id,
    productId: d.product_id,
    amount: parseFloat(String(d.amount)),
    sellerAmount: parseFloat(String(d.seller_amount)),
    commission: parseFloat(String(d.commission)),
    status: d.status,
    deliveryData: d.delivery_data,
    buyerConfirmed: Boolean(d.buyer_confirmed),
    sellerConfirmed: Boolean(d.seller_confirmed),
    autoCompleteAt: d.auto_complete_at,
    disputeReason: d.dispute_reason,
    createdAt: d.created_at,
    buyer: d.buyer_username ? { id: d.buyer_id, username: d.buyer_username, firstName: d.buyer_first_name, avatar: d.buyer_avatar } : undefined,
    seller: d.seller_username ? { id: d.seller_id, username: d.seller_username, firstName: d.seller_first_name, avatar: d.seller_avatar } : undefined,
    product: d.product_title ? {
      id: d.product_id, title: d.product_title, price: parseFloat(String(d.product_price)),
      category: d.product_category,
      images: typeof d.product_images === "string" ? JSON.parse(d.product_images as string || "[]") : [],
    } : undefined,
  };
}

const DEAL_SELECT = `
  SELECT d.*,
    bu.username as buyer_username, bu.first_name as buyer_first_name, bu.avatar as buyer_avatar,
    su.username as seller_username, su.first_name as seller_first_name, su.avatar as seller_avatar,
    p.title as product_title, p.price as product_price, p.category as product_category, p.images as product_images
  FROM deals d
  LEFT JOIN users bu ON bu.id = d.buyer_id
  LEFT JOIN users su ON su.id = d.seller_id
  LEFT JOIN products p ON p.id = d.product_id
`;

router.get("/", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { role, status, page = "1", limit = "20" } = req.query;
    const lim = Math.min(parseInt(String(limit)) || 20, 50);
    const offset = (Math.max(parseInt(String(page)) || 1, 1) - 1) * lim;

    const conditions = [`(d.buyer_id = $1 OR d.seller_id = $1)`];
    const params: unknown[] = [req.userId];
    let pidx = 2;

    if (role === "buyer") { conditions[0] = `d.buyer_id = $1`; }
    if (role === "seller") { conditions[0] = `d.seller_id = $1`; }
    if (status) { conditions.push(`d.status = $${pidx}`); params.push(status); pidx++; }

    const where = "WHERE " + conditions.join(" AND ");
    const countRes = await queryOne<{ c: string }>(`SELECT COUNT(*) as c FROM deals d ${where}`, params);
    const total = parseInt(countRes?.c || "0");
    const deals = await queryAll<Record<string, unknown>>(
      `${DEAL_SELECT} ${where} ORDER BY d.created_at DESC LIMIT $${pidx} OFFSET $${pidx + 1}`,
      [...params, lim, offset]
    );
    res.json({ deals: deals.map(parseDeal), total, page: parseInt(String(page)), totalPages: Math.ceil(total / lim) });
  } catch (e) {
    req.log?.error(e);
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { productId } = req.body;
    if (!productId) { res.status(400).json({ error: "productId обязателен" }); return; }

    const product = await queryOne<Record<string, unknown>>("SELECT * FROM products WHERE id = $1 AND status = 'active'", [productId]);
    if (!product) { res.status(404).json({ error: "Товар не найден или недоступен" }); return; }
    if (product.seller_id === req.userId) { res.status(400).json({ error: "Нельзя купить свой товар" }); return; }

    const buyer = await queryOne<Record<string, unknown>>("SELECT * FROM users WHERE id = $1", [req.userId]);
    if (!buyer) { res.status(401).json({ error: "Не авторизован" }); return; }

    const price = parseFloat(String(product.price));
    if ((parseFloat(String(buyer.balance)) || 0) < price) {
      res.status(400).json({ error: "Недостаточно средств на балансе" }); return;
    }

    const commission = Math.round(price * COMMISSION * 100) / 100;
    const sellerAmount = price - commission;
    const { v4: uuidv4 } = await import("uuid");
    const id = uuidv4();
    const autoAt = Math.floor(Date.now() / 1000) + 72 * 3600; // 3 days

    await run("BEGIN");
    try {
      await run(`INSERT INTO deals (id, buyer_id, seller_id, product_id, amount, seller_amount, commission, status, auto_complete_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,'active',$8)`,
        [id, req.userId, product.seller_id, productId, price, sellerAmount, commission, autoAt]);
      await run("UPDATE products SET status = 'frozen' WHERE id = $1", [productId]);
      await run("UPDATE users SET balance = balance - $1, frozen_balance = frozen_balance + $1 WHERE id = $2", [price, req.userId]);
      await run("COMMIT");
    } catch (e) {
      await run("ROLLBACK");
      throw e;
    }

    const deal = await queryOne<Record<string, unknown>>(`${DEAL_SELECT} WHERE d.id = $1`, [id]);
    res.status(201).json(parseDeal(deal!));
  } catch (e) {
    req.log?.error(e);
    res.status(500).json({ error: "Ошибка создания сделки" });
  }
});

router.get("/:id", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const deal = await queryOne<Record<string, unknown>>(`${DEAL_SELECT} WHERE d.id = $1`, [req.params.id]);
    if (!deal) { res.status(404).json({ error: "Не найдена" }); return; }
    if (deal.buyer_id !== req.userId && deal.seller_id !== req.userId && !req.user?.is_admin) {
      res.status(403).json({ error: "Нет доступа" }); return;
    }
    res.json(parseDeal(deal));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/:id/deliver", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const deal = await queryOne<Record<string, unknown>>("SELECT * FROM deals WHERE id = $1", [req.params.id]);
    if (!deal) { res.status(404).json({ error: "Не найдена" }); return; }
    if (deal.seller_id !== req.userId) { res.status(403).json({ error: "Нет доступа" }); return; }
    if (deal.status !== "active") { res.status(400).json({ error: "Неверный статус сделки" }); return; }

    const { deliveryData } = req.body;
    if (!deliveryData) { res.status(400).json({ error: "Данные доставки обязательны" }); return; }

    await run(
      "UPDATE deals SET delivery_data = $1, delivered_at = EXTRACT(EPOCH FROM NOW())::BIGINT, seller_confirmed = 1 WHERE id = $2",
      [deliveryData, req.params.id]
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/:id/confirm", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const deal = await queryOne<Record<string, unknown>>("SELECT * FROM deals WHERE id = $1", [req.params.id]);
    if (!deal) { res.status(404).json({ error: "Не найдена" }); return; }
    if (deal.buyer_id !== req.userId) { res.status(403).json({ error: "Нет доступа" }); return; }
    if (!["active"].includes(String(deal.status))) { res.status(400).json({ error: "Неверный статус" }); return; }

    await run("BEGIN");
    try {
      const now = Math.floor(Date.now() / 1000);
      await run(`UPDATE deals SET status = 'completed', buyer_confirmed = 1, completed_at = $1 WHERE id = $2`, [now, req.params.id]);
      await run("UPDATE users SET balance = balance - $1, frozen_balance = frozen_balance - $1 WHERE id = $2", [deal.amount, deal.buyer_id]);
      await run("UPDATE users SET balance = balance + $1, total_sales = total_sales + 1 WHERE id = $2", [deal.seller_amount, deal.seller_id]);
      await run("UPDATE users SET total_purchases = total_purchases + 1 WHERE id = $1", [deal.buyer_id]);
      await run("UPDATE products SET status = 'sold', sold_count = sold_count + 1 WHERE id = $1", [deal.product_id]);
      await run("COMMIT");
    } catch (e) {
      await run("ROLLBACK");
      throw e;
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: "Ошибка подтверждения" });
  }
});

router.post("/:id/dispute", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const deal = await queryOne<Record<string, unknown>>("SELECT * FROM deals WHERE id = $1", [req.params.id]);
    if (!deal) { res.status(404).json({ error: "Не найдена" }); return; }
    if (deal.buyer_id !== req.userId && deal.seller_id !== req.userId) { res.status(403).json({ error: "Нет доступа" }); return; }
    if (deal.status !== "active") { res.status(400).json({ error: "Неверный статус" }); return; }

    const { reason } = req.body;
    await run("UPDATE deals SET status = 'disputed', dispute_reason = $1 WHERE id = $2", [reason || "Спор открыт", req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/:id/review", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const deal = await queryOne<Record<string, unknown>>("SELECT * FROM deals WHERE id = $1", [req.params.id]);
    if (!deal) { res.status(404).json({ error: "Не найдена" }); return; }
    if (deal.buyer_id !== req.userId) { res.status(403).json({ error: "Только покупатель может оставить отзыв" }); return; }
    if (deal.status !== "completed") { res.status(400).json({ error: "Сделка не завершена" }); return; }

    const { rating, text } = req.body;
    if (!rating || rating < 1 || rating > 5) { res.status(400).json({ error: "Рейтинг 1-5" }); return; }

    const existing = await queryOne("SELECT id FROM reviews WHERE deal_id = $1", [req.params.id]);
    if (existing) { res.status(409).json({ error: "Отзыв уже оставлен" }); return; }

    const { v4: uuidv4 } = await import("uuid");
    const id = uuidv4();
    await run(
      "INSERT INTO reviews (id, deal_id, reviewer_id, reviewed_id, rating, text) VALUES ($1,$2,$3,$4,$5,$6)",
      [id, req.params.id, req.userId, deal.seller_id, rating, text || null]
    );

    // Update seller rating
    const ratingRow = await queryOne<{ avg: string; cnt: string }>(
      "SELECT AVG(rating) as avg, COUNT(*) as cnt FROM reviews WHERE reviewed_id = $1",
      [deal.seller_id]
    );
    if (ratingRow) {
      await run("UPDATE users SET rating = $1, review_count = $2 WHERE id = $3",
        [parseFloat(ratingRow.avg).toFixed(1), ratingRow.cnt, deal.seller_id]);
    }
    res.status(201).json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

export default router;
