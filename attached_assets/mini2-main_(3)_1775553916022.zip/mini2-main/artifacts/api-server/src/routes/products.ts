import { Router } from "express";
import { queryOne, queryAll, run } from "../lib/db";
import { authMiddleware, type AuthRequest } from "../lib/auth";

const router = Router();

const PRODUCT_SELECT = `
  SELECT p.*,
    (SELECT COUNT(*) FROM favorites f WHERE f.product_id = p.id) as fav_count,
    u.username     as seller_username,
    u.first_name   as seller_first_name,
    u.avatar       as seller_avatar,
    u.rating       as seller_rating,
    u.review_count as seller_review_count,
    u.total_sales  as seller_total_sales,
    u.is_verified  as seller_is_verified
  FROM products p
  LEFT JOIN users u ON u.id = p.seller_id
`;

function parseProduct(p: Record<string, unknown>, userId?: string) {
  if (!p) return null;
  const images = typeof p.images === "string" ? JSON.parse(p.images as string || "[]") : (p.images || []);
  const tags = typeof p.tags === "string" ? JSON.parse(p.tags as string || "[]") : (p.tags || []);
  return {
    id: p.id,
    sellerId: p.seller_id,
    seller: p.seller_username ? {
      id: p.seller_id,
      username: p.seller_username,
      firstName: p.seller_first_name,
      avatar: p.seller_avatar,
      rating: parseFloat(String(p.seller_rating)) || 5,
      reviewCount: Number(p.seller_review_count) || 0,
      totalSales: Number(p.seller_total_sales) || 0,
      isVerified: Boolean(p.seller_is_verified),
    } : undefined,
    title: p.title,
    description: p.description,
    price: parseFloat(String(p.price)),
    category: p.category,
    subcategory: p.subcategory,
    images,
    deliveryType: p.delivery_type,
    game: p.game,
    server: p.server,
    status: p.status,
    views: Number(p.views) || 0,
    soldCount: Number(p.sold_count) || 0,
    tags,
    isPromoted: Boolean(p.is_promoted),
    isFavorited: false,
    createdAt: p.created_at,
  };
}

router.get("/featured", async (req, res) => {
  try {
    const products = await queryAll<Record<string, unknown>>(
      `${PRODUCT_SELECT} WHERE p.status = 'active' AND p.is_promoted = 1 ORDER BY p.created_at DESC LIMIT 8`
    );
    if (products.length < 4) {
      const extra = await queryAll<Record<string, unknown>>(
        `${PRODUCT_SELECT} WHERE p.status = 'active' ORDER BY p.views DESC, p.created_at DESC LIMIT 8`
      );
      const merged = [...products, ...extra].slice(0, 8);
      res.json(merged.map(p => parseProduct(p)));
      return;
    }
    res.json(products.map(p => parseProduct(p)));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.get("/stats", async (_req, res) => {
  try {
    const [productsRow, dealsRow, usersRow, volumeRow] = await Promise.all([
      queryOne<{ c: string }>("SELECT COUNT(*) as c FROM products WHERE status = 'active'"),
      queryOne<{ c: string }>("SELECT COUNT(*) as c FROM deals"),
      queryOne<{ c: string }>("SELECT COUNT(*) as c FROM users"),
      queryOne<{ v: string }>("SELECT COALESCE(SUM(amount),0) as v FROM deals WHERE status = 'completed'"),
    ]);
    const recentProducts = await queryAll<Record<string, unknown>>(
      `${PRODUCT_SELECT} WHERE p.status = 'active' ORDER BY p.created_at DESC LIMIT 4`
    );
    const topSellers = await queryAll<Record<string, unknown>>(
      `SELECT id, username, first_name, avatar, rating, review_count, total_sales, is_verified
       FROM users WHERE total_sales > 0 ORDER BY total_sales DESC LIMIT 5`
    );
    res.json({
      totalProducts: parseInt(productsRow?.c || "0"),
      totalDeals: parseInt(dealsRow?.c || "0"),
      totalUsers: parseInt(usersRow?.c || "0"),
      totalVolume: parseFloat(volumeRow?.v || "0"),
      recentProducts: recentProducts.map(p => parseProduct(p)),
      topSellers: topSellers.map(u => ({
        id: u.id, username: u.username, firstName: u.first_name,
        avatar: u.avatar, rating: parseFloat(String(u.rating)) || 5,
        reviewCount: Number(u.review_count) || 0, totalSales: Number(u.total_sales) || 0,
        isVerified: Boolean(u.is_verified),
      })),
    });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.get("/", async (req, res) => {
  try {
    const { category, game, search, sort = "newest", minPrice, maxPrice, limit = "20", page = "1" } = req.query;
    const lim = Math.min(parseInt(String(limit)) || 20, 50);
    const offset = (Math.max(parseInt(String(page)) || 1, 1) - 1) * lim;

    const conditions = ["p.status = 'active'"];
    const params: unknown[] = [];
    let pidx = 1;

    if (search) {
      conditions.push(`(p.title ILIKE $${pidx} OR p.description ILIKE $${pidx})`);
      params.push("%" + String(search).trim() + "%");
      pidx++;
    }
    if (category) { conditions.push(`p.category = $${pidx}`); params.push(category); pidx++; }
    if (game) { conditions.push(`p.game ILIKE $${pidx}`); params.push("%" + String(game) + "%"); pidx++; }
    if (minPrice) { conditions.push(`p.price >= $${pidx}`); params.push(parseFloat(String(minPrice))); pidx++; }
    if (maxPrice) { conditions.push(`p.price <= $${pidx}`); params.push(parseFloat(String(maxPrice))); pidx++; }

    const where = "WHERE " + conditions.join(" AND ");
    const orderMap: Record<string, string> = {
      newest: "p.is_promoted DESC, p.created_at DESC",
      price_asc: "p.is_promoted DESC, p.price ASC",
      price_desc: "p.is_promoted DESC, p.price DESC",
      popular: "p.is_promoted DESC, p.views DESC",
    };
    const order = orderMap[String(sort)] || orderMap.newest;

    const countRes = await queryOne<{ c: string }>(`SELECT COUNT(*) as c FROM products p ${where}`, params);
    const total = parseInt(countRes?.c || "0");
    const products = await queryAll<Record<string, unknown>>(
      `${PRODUCT_SELECT} ${where} ORDER BY ${order} LIMIT $${pidx} OFFSET $${pidx + 1}`,
      [...params, lim, offset]
    );

    res.json({ products: products.map(p => parseProduct(p)), total, page: parseInt(String(page)), totalPages: Math.ceil(total / lim) });
  } catch (e) {
    req.log?.error(e);
    res.status(500).json({ error: "Ошибка" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const product = await queryOne<Record<string, unknown>>(`${PRODUCT_SELECT} WHERE p.id = $1`, [req.params.id]);
    if (!product) { res.status(404).json({ error: "Не найден" }); return; }
    await run("UPDATE products SET views = views + 1 WHERE id = $1", [req.params.id]);
    const parsed = parseProduct(product);
    if (parsed) parsed.views = (parsed.views as number) + 1;
    res.json(parsed);
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { title, description, price, category, subcategory, game, server, deliveryData, deliveryType, tags, images } = req.body;
    if (!title || !description || price == null || !category) {
      res.status(400).json({ error: "Заполните обязательные поля" });
      return;
    }
    const { v4: uuidv4 } = await import("uuid");
    const id = uuidv4();
    await run(`
      INSERT INTO products (id, seller_id, title, description, price, category, subcategory, game, server, delivery_data, delivery_type, tags, images)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
    `, [id, req.userId, title.trim(), description.trim(), parseFloat(String(price)), category,
      subcategory || null, game || null, server || null, deliveryData || null,
      deliveryType || "manual",
      JSON.stringify(Array.isArray(tags) ? tags.slice(0, 10) : []),
      JSON.stringify(Array.isArray(images) ? images.slice(0, 5) : [])]);

    const product = await queryOne<Record<string, unknown>>(`${PRODUCT_SELECT} WHERE p.id = $1`, [id]);
    res.status(201).json(parseProduct(product!));
  } catch (e) {
    req.log?.error(e);
    res.status(500).json({ error: "Ошибка создания" });
  }
});

router.put("/:id", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const product = await queryOne<Record<string, unknown>>("SELECT * FROM products WHERE id = $1", [req.params.id]);
    if (!product) { res.status(404).json({ error: "Не найден" }); return; }
    if (product.seller_id !== req.userId && !req.user?.is_admin) {
      res.status(403).json({ error: "Нет доступа" }); return;
    }
    const { title, description, price, category, images, status } = req.body;
    await run(`
      UPDATE products SET
        title       = COALESCE($1, title),
        description = COALESCE($2, description),
        price       = COALESCE($3, price),
        category    = COALESCE($4, category),
        images      = COALESCE($5, images),
        status      = COALESCE($6, status),
        updated_at  = EXTRACT(EPOCH FROM NOW())::BIGINT
      WHERE id = $7
    `, [title || null, description || null, price ? parseFloat(String(price)) : null,
      category || null, images ? JSON.stringify(images) : null, status || null, req.params.id]);
    const updated = await queryOne<Record<string, unknown>>(`${PRODUCT_SELECT} WHERE p.id = $1`, [req.params.id]);
    res.json(parseProduct(updated!));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.delete("/:id", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const product = await queryOne<Record<string, unknown>>("SELECT * FROM products WHERE id = $1", [req.params.id]);
    if (!product) { res.status(404).json({ error: "Не найден" }); return; }
    if (product.seller_id !== req.userId && !req.user?.is_admin) {
      res.status(403).json({ error: "Нет доступа" }); return;
    }
    await run("UPDATE products SET status = 'deleted' WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/:id/favorite", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const existing = await queryOne("SELECT 1 FROM favorites WHERE user_id = $1 AND product_id = $2", [req.userId, req.params.id]);
    if (existing) {
      await run("DELETE FROM favorites WHERE user_id = $1 AND product_id = $2", [req.userId, req.params.id]);
      res.json({ favorited: false });
    } else {
      await run("INSERT INTO favorites (user_id, product_id) VALUES ($1,$2) ON CONFLICT DO NOTHING", [req.userId, req.params.id]);
      res.json({ favorited: true });
    }
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

export default router;
