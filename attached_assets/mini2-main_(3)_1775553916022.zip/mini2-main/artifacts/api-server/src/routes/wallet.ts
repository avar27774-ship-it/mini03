import { Router } from "express";
import { queryOne, queryAll, run } from "../lib/db";
import { authMiddleware, type AuthRequest } from "../lib/auth";

const router = Router();

router.get("/balance", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const user = await queryOne<Record<string, unknown>>("SELECT balance, frozen_balance, total_deposited, total_withdrawn FROM users WHERE id = $1", [req.userId]);
    if (!user) { res.status(404).json({ error: "Не найден" }); return; }
    res.json({
      balance: parseFloat(String(user.balance)) || 0,
      frozenBalance: parseFloat(String(user.frozen_balance)) || 0,
      totalDeposited: parseFloat(String(user.total_deposited)) || 0,
      totalWithdrawn: parseFloat(String(user.total_withdrawn)) || 0,
    });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.get("/transactions", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { page = "1", limit = "20" } = req.query;
    const lim = Math.min(parseInt(String(limit)) || 20, 50);
    const offset = (Math.max(parseInt(String(page)) || 1, 1) - 1) * lim;

    const countRes = await queryOne<{ c: string }>("SELECT COUNT(*) as c FROM transactions WHERE user_id = $1", [req.userId]);
    const total = parseInt(countRes?.c || "0");
    const transactions = await queryAll<Record<string, unknown>>(
      "SELECT * FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3",
      [req.userId, lim, offset]
    );
    res.json({
      transactions: transactions.map(t => ({
        id: t.id, type: t.type, amount: parseFloat(String(t.amount)), currency: t.currency,
        status: t.status, description: t.description, gatewayType: t.gateway_type,
        gatewayPayUrl: t.gateway_pay_url, balanceBefore: t.balance_before, balanceAfter: t.balance_after,
        createdAt: t.created_at,
      })),
      total,
    });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/deposit", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { amount, gateway = "manual" } = req.body;
    if (!amount || parseFloat(String(amount)) < 10) {
      res.status(400).json({ error: "Минимальная сумма 10 руб." }); return;
    }
    const amountNum = parseFloat(String(amount));
    const { v4: uuidv4 } = await import("uuid");
    const orderId = uuidv4();

    const user = await queryOne<Record<string, unknown>>("SELECT balance FROM users WHERE id = $1", [req.userId]);
    const balanceBefore = parseFloat(String(user?.balance)) || 0;

    // In production you'd integrate with a payment gateway. For now, simulate pending deposit.
    await run(`
      INSERT INTO transactions (id, user_id, type, amount, currency, status, description, gateway_type, gateway_order_id, balance_before)
      VALUES ($1,$2,'deposit',$3,'RUB','pending',$4,$5,$6,$7)
    `, [uuidv4(), req.userId, amountNum, `Пополнение баланса ${amountNum} руб.`, gateway, orderId, balanceBefore]);

    // For demo: immediately credit the balance (remove in production with real payment gateway)
    await run("UPDATE users SET balance = balance + $1, total_deposited = total_deposited + $1 WHERE id = $2", [amountNum, req.userId]);
    await run("UPDATE transactions SET status = 'completed', balance_after = $1 WHERE gateway_order_id = $2",
      [balanceBefore + amountNum, orderId]);

    res.json({ payUrl: `/wallet?deposited=${amountNum}`, orderId });
  } catch (e) {
    res.status(500).json({ error: "Ошибка пополнения" });
  }
});

router.post("/withdraw", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { amount, method, details } = req.body;
    if (!amount || !method || !details) {
      res.status(400).json({ error: "Заполните все поля" }); return;
    }
    const amountNum = parseFloat(String(amount));
    if (amountNum < 100) { res.status(400).json({ error: "Минимальный вывод 100 руб." }); return; }

    const user = await queryOne<Record<string, unknown>>("SELECT balance FROM users WHERE id = $1", [req.userId]);
    const balance = parseFloat(String(user?.balance)) || 0;
    if (balance < amountNum) { res.status(400).json({ error: "Недостаточно средств" }); return; }

    const { v4: uuidv4 } = await import("uuid");
    await run(`
      INSERT INTO transactions (id, user_id, type, amount, currency, status, description, gateway_type, balance_before)
      VALUES ($1,$2,'withdrawal',$3,'RUB','pending',$4,$5,$6)
    `, [uuidv4(), req.userId, amountNum, `Вывод ${amountNum} руб. на ${method} (${details})`, method, balance]);

    await run("UPDATE users SET balance = balance - $1, total_withdrawn = total_withdrawn + $1 WHERE id = $2", [amountNum, req.userId]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: "Ошибка вывода" });
  }
});

export default router;
