import { Router } from "express";
import bcrypt from "bcryptjs";
import { queryOne, run } from "../lib/db";
import { generateToken, sanitizeUser, authMiddleware, type AuthRequest } from "../lib/auth";

const router = Router();

function validateUsername(u: string) {
  return /^[a-z0-9_]{3,24}$/.test(u);
}

router.post("/register", async (req, res) => {
  try {
    const { username, password, firstName } = req.body;
    if (!username || !password) {
      res.status(400).json({ error: "Заполните все поля" });
      return;
    }
    if (!validateUsername(username.toLowerCase())) {
      res.status(400).json({ error: "Логин: 3-24 символа, только a-z 0-9 _" });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: "Пароль минимум 6 символов" });
      return;
    }

    const uname = username.toLowerCase();
    const existing = await queryOne("SELECT id FROM users WHERE username = $1", [uname]);
    if (existing) {
      res.status(409).json({ error: "Логин уже занят" });
      return;
    }

    const hash = await bcrypt.hash(password, 12);
    const { v4: uuidv4 } = await import("uuid");
    const id = uuidv4();
    await run(
      `INSERT INTO users (id, username, password, first_name, created_at, last_active)
       VALUES ($1, $2, $3, $4, EXTRACT(EPOCH FROM NOW())::BIGINT, EXTRACT(EPOCH FROM NOW())::BIGINT)`,
      [id, uname, hash, firstName || null]
    );

    const user = await queryOne<Record<string, unknown>>("SELECT * FROM users WHERE id = $1", [id]);
    const token = generateToken(id);
    res.json({ token, user: sanitizeUser(user) });
  } catch (e) {
    req.log?.error(e, "Register error");
    res.status(500).json({ error: "Ошибка регистрации" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      res.status(400).json({ error: "Заполните все поля" });
      return;
    }

    const user = await queryOne<Record<string, unknown>>(
      "SELECT * FROM users WHERE username = $1",
      [username.toLowerCase()]
    );
    if (!user || !user.password) {
      res.status(401).json({ error: "Неверный логин или пароль" });
      return;
    }

    const ok = await bcrypt.compare(password, String(user.password));
    if (!ok) {
      res.status(401).json({ error: "Неверный логин или пароль" });
      return;
    }

    if (user.is_banned) {
      res.status(403).json({ error: "Аккаунт заблокирован" });
      return;
    }

    await run("UPDATE users SET last_active = EXTRACT(EPOCH FROM NOW())::BIGINT WHERE id = $1", [user.id]);
    const token = generateToken(String(user.id));
    res.json({ token, user: sanitizeUser(user) });
  } catch (e) {
    req.log?.error(e, "Login error");
    res.status(500).json({ error: "Ошибка входа" });
  }
});

router.get("/me", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const user = await queryOne<Record<string, unknown>>("SELECT * FROM users WHERE id = $1", [req.userId]);
    res.json(sanitizeUser(user));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

export default router;
