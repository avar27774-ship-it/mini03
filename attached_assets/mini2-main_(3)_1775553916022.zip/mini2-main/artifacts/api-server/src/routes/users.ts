import { Router } from "express";
import { queryOne, queryAll, run } from "../lib/db";
import { authMiddleware, sanitizeUser, type AuthRequest } from "../lib/auth";

const router = Router();

router.get("/:id", async (req, res) => {
  try {
    const user = await queryOne<Record<string, unknown>>("SELECT * FROM users WHERE id = $1", [req.params.id]);
    if (!user) { res.status(404).json({ error: "Не найден" }); return; }

    const reviews = await queryAll<Record<string, unknown>>(`
      SELECT r.*, u.username as reviewer_username, u.first_name as reviewer_first_name, u.avatar as reviewer_avatar
      FROM reviews r
      LEFT JOIN users u ON u.id = r.reviewer_id
      WHERE r.reviewed_id = $1
      ORDER BY r.created_at DESC LIMIT 10
    `, [req.params.id]);

    const profile = sanitizeUser(user);
    if (profile) {
      profile.reviews = reviews.map(r => ({
        id: r.id, dealId: r.deal_id, rating: r.rating, text: r.text, createdAt: r.created_at,
        reviewerId: r.reviewer_id,
        reviewer: { id: r.reviewer_id, username: r.reviewer_username, firstName: r.reviewer_first_name, avatar: r.reviewer_avatar },
      }));
    }
    res.json(profile);
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.get("/:id/products", async (req, res) => {
  try {
    const { page = "1", limit = "12" } = req.query;
    const lim = Math.min(parseInt(String(limit)) || 12, 50);
    const offset = (Math.max(parseInt(String(page)) || 1, 1) - 1) * lim;

    const countRes = await queryOne<{ c: string }>(
      "SELECT COUNT(*) as c FROM products WHERE seller_id = $1 AND status = 'active'",
      [req.params.id]
    );
    const total = parseInt(countRes?.c || "0");
    const products = await queryAll<Record<string, unknown>>(`
      SELECT p.*, u.username as seller_username, u.first_name as seller_first_name, u.avatar as seller_avatar, u.rating as seller_rating, u.review_count as seller_review_count, u.total_sales as seller_total_sales, u.is_verified as seller_is_verified
      FROM products p LEFT JOIN users u ON u.id = p.seller_id
      WHERE p.seller_id = $1 AND p.status = 'active'
      ORDER BY p.created_at DESC LIMIT $2 OFFSET $3
    `, [req.params.id, lim, offset]);

    res.json({
      products: products.map(p => ({
        id: p.id, sellerId: p.seller_id, title: p.title, description: p.description,
        price: parseFloat(String(p.price)), category: p.category,
        images: typeof p.images === "string" ? JSON.parse(p.images as string || "[]") : (p.images || []),
        deliveryType: p.delivery_type, game: p.game, views: p.views, soldCount: p.sold_count,
        isPromoted: Boolean(p.is_promoted), createdAt: p.created_at,
        seller: { id: p.seller_id, username: p.seller_username, firstName: p.seller_first_name, avatar: p.seller_avatar, rating: parseFloat(String(p.seller_rating)) || 5, reviewCount: Number(p.seller_review_count) || 0, totalSales: Number(p.seller_total_sales) || 0, isVerified: Boolean(p.seller_is_verified) }
      })),
      total, page: parseInt(String(page)), totalPages: Math.ceil(total / lim),
    });
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.put("/me/profile", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { firstName, lastName, bio, avatar } = req.body;
    await run(
      "UPDATE users SET first_name = COALESCE($1, first_name), last_name = COALESCE($2, last_name), bio = COALESCE($3, bio), avatar = COALESCE($4, avatar) WHERE id = $5",
      [firstName || null, lastName || null, bio || null, avatar || null, req.userId]
    );
    const user = await queryOne<Record<string, unknown>>("SELECT * FROM users WHERE id = $1", [req.userId]);
    res.json(sanitizeUser(user));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.get("/me/favorites", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const products = await queryAll<Record<string, unknown>>(`
      SELECT p.*, u.username as seller_username, u.first_name as seller_first_name, u.avatar as seller_avatar, u.rating as seller_rating
      FROM favorites f
      JOIN products p ON p.id = f.product_id
      LEFT JOIN users u ON u.id = p.seller_id
      WHERE f.user_id = $1 AND p.status = 'active'
      ORDER BY f.created_at DESC
    `, [req.userId]);
    res.json(products.map(p => ({
      id: p.id, sellerId: p.seller_id, title: p.title, price: parseFloat(String(p.price)),
      category: p.category, images: typeof p.images === "string" ? JSON.parse(p.images as string || "[]") : [],
      isFavorited: true, createdAt: p.created_at,
      seller: { id: p.seller_id, username: p.seller_username, firstName: p.seller_first_name, avatar: p.seller_avatar, rating: parseFloat(String(p.seller_rating)) || 5 },
    })));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

export default router;
