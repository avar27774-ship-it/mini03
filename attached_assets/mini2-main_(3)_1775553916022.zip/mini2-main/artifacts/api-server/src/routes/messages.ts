import { Router } from "express";
import { queryOne, queryAll, run } from "../lib/db";
import { authMiddleware, type AuthRequest } from "../lib/auth";

const router = Router();

function parseMessage(m: Record<string, unknown>) {
  return {
    id: m.id,
    senderId: m.sender_id,
    receiverId: m.receiver_id,
    text: m.text,
    isRead: Boolean(m.is_read),
    createdAt: m.created_at,
    sender: m.sender_username ? {
      id: m.sender_id,
      username: m.sender_username,
      firstName: m.sender_first_name,
      avatar: m.sender_avatar,
    } : undefined,
  };
}

router.get("/", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const chats = await queryAll<Record<string, unknown>>(`
      SELECT DISTINCT ON (other_user_id)
        CASE WHEN m.sender_id = $1 THEN m.receiver_id ELSE m.sender_id END as other_user_id,
        m.*,
        u.username as other_username, u.first_name as other_first_name, u.avatar as other_avatar,
        (SELECT COUNT(*) FROM messages WHERE receiver_id = $1 AND sender_id = other_user_id AND is_read = 0) as unread_count
      FROM messages m
      JOIN users u ON u.id = (CASE WHEN m.sender_id = $1 THEN m.receiver_id ELSE m.sender_id END)
      WHERE m.sender_id = $1 OR m.receiver_id = $1
      ORDER BY other_user_id, m.created_at DESC
    `, [req.userId]);

    res.json(chats.map(c => ({
      userId: c.other_user_id,
      user: { id: c.other_user_id, username: c.other_username, firstName: c.other_first_name, avatar: c.other_avatar },
      lastMessage: { id: c.id, senderId: c.sender_id, receiverId: c.receiver_id, text: c.text, isRead: Boolean(c.is_read), createdAt: c.created_at },
      unreadCount: parseInt(String(c.unread_count)) || 0,
    })));
  } catch (e) {
    req.log?.error(e);
    res.status(500).json({ error: "Ошибка" });
  }
});

router.get("/:userId", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { page = "1" } = req.query;
    const lim = 50;
    const offset = (Math.max(parseInt(String(page)) || 1, 1) - 1) * lim;

    const messages = await queryAll<Record<string, unknown>>(`
      SELECT m.*, u.username as sender_username, u.first_name as sender_first_name, u.avatar as sender_avatar
      FROM messages m
      LEFT JOIN users u ON u.id = m.sender_id
      WHERE (m.sender_id = $1 AND m.receiver_id = $2) OR (m.sender_id = $2 AND m.receiver_id = $1)
      ORDER BY m.created_at DESC LIMIT $3 OFFSET $4
    `, [req.userId, req.params.userId, lim, offset]);

    // Mark messages as read
    await run(
      "UPDATE messages SET is_read = 1 WHERE receiver_id = $1 AND sender_id = $2 AND is_read = 0",
      [req.userId, req.params.userId]
    );

    res.json(messages.reverse().map(parseMessage));
  } catch (e) {
    res.status(500).json({ error: "Ошибка" });
  }
});

router.post("/:userId", authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { text } = req.body;
    if (!text?.trim()) { res.status(400).json({ error: "Сообщение не может быть пустым" }); return; }

    const receiver = await queryOne("SELECT id FROM users WHERE id = $1", [req.params.userId]);
    if (!receiver) { res.status(404).json({ error: "Пользователь не найден" }); return; }
    if (req.params.userId === req.userId) { res.status(400).json({ error: "Нельзя писать самому себе" }); return; }

    const { v4: uuidv4 } = await import("uuid");
    const id = uuidv4();
    await run(
      "INSERT INTO messages (id, sender_id, receiver_id, text) VALUES ($1,$2,$3,$4)",
      [id, req.userId, req.params.userId, text.trim()]
    );

    const message = await queryOne<Record<string, unknown>>(`
      SELECT m.*, u.username as sender_username, u.first_name as sender_first_name, u.avatar as sender_avatar
      FROM messages m LEFT JOIN users u ON u.id = m.sender_id WHERE m.id = $1
    `, [id]);

    res.status(201).json(parseMessage(message!));
  } catch (e) {
    res.status(500).json({ error: "Ошибка отправки" });
  }
});

export default router;
