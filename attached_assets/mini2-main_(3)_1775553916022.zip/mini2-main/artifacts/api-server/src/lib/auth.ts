import jwt from "jsonwebtoken";
import type { Request, Response, NextFunction } from "express";
import { queryOne } from "./db";

const JWT_SECRET = process.env.JWT_SECRET || process.env.SESSION_SECRET || "changeme";

export function generateToken(userId: string): string {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "30d" });
}

export interface AuthRequest extends Request {
  userId?: string;
  user?: Record<string, unknown>;
}

export async function authMiddleware(
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const header = req.headers.authorization;
    if (!header?.startsWith("Bearer ")) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    const token = header.slice(7);
    const payload = jwt.verify(token, JWT_SECRET) as { userId: string };
    req.userId = payload.userId;
    const user = await queryOne("SELECT * FROM users WHERE id = $1", [payload.userId]);
    if (!user) {
      res.status(401).json({ error: "User not found" });
      return;
    }
    req.user = user as Record<string, unknown>;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

export function sanitizeUser(u: Record<string, unknown> | null) {
  if (!u) return null;
  const safe = { ...u };
  delete safe.password;
  safe.id = u.id;
  safe.username = u.username;
  safe.firstName = u.first_name;
  safe.lastName = u.last_name;
  safe.avatar = u.avatar || u.photo_url;
  safe.bio = u.bio;
  safe.balance = parseFloat(String(u.balance)) || 0;
  safe.frozenBalance = parseFloat(String(u.frozen_balance)) || 0;
  safe.totalDeposited = parseFloat(String(u.total_deposited)) || 0;
  safe.totalWithdrawn = parseFloat(String(u.total_withdrawn)) || 0;
  safe.totalSales = Number(u.total_sales) || 0;
  safe.totalPurchases = Number(u.total_purchases) || 0;
  safe.rating = parseFloat(String(u.rating)) || 5;
  safe.reviewCount = Number(u.review_count) || 0;
  safe.isAdmin = Boolean(u.is_admin);
  safe.isVerified = Boolean(u.is_verified);
  safe.isBanned = Boolean(u.is_banned);
  safe.sellerLevel = u.seller_level || "newcomer";
  safe.refCode = u.ref_code;
  safe.createdAt = u.created_at;
  return safe;
}
