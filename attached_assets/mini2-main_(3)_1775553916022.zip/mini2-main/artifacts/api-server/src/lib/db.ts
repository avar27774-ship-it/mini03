import pg from "pg";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

export async function queryOne<T = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<T | null> {
  const client = await pool.connect();
  try {
    const res = await client.query(text, params);
    return (res.rows[0] as T) || null;
  } finally {
    client.release();
  }
}

export async function queryAll<T = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<T[]> {
  const client = await pool.connect();
  try {
    const res = await client.query(text, params);
    return res.rows as T[];
  } finally {
    client.release();
  }
}

export async function run(text: string, params?: unknown[]): Promise<pg.QueryResult> {
  const client = await pool.connect();
  try {
    return await client.query(text, params);
  } finally {
    client.release();
  }
}

export async function initSchema(): Promise<void> {
  await run(`
    CREATE TABLE IF NOT EXISTS users (
      id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      username        TEXT UNIQUE,
      password        TEXT,
      first_name      TEXT,
      last_name       TEXT,
      avatar          TEXT,
      bio             TEXT,
      balance         NUMERIC(12,2) DEFAULT 0,
      frozen_balance  NUMERIC(12,2) DEFAULT 0,
      total_deposited NUMERIC(12,2) DEFAULT 0,
      total_withdrawn NUMERIC(12,2) DEFAULT 0,
      total_sales     INTEGER DEFAULT 0,
      total_purchases INTEGER DEFAULT 0,
      total_volume    NUMERIC(12,2) DEFAULT 0,
      rating          NUMERIC(3,1) DEFAULT 5.0,
      review_count    INTEGER DEFAULT 0,
      is_admin        INTEGER DEFAULT 0,
      is_verified     INTEGER DEFAULT 0,
      is_banned       INTEGER DEFAULT 0,
      seller_level    TEXT DEFAULT 'newcomer',
      ref_code        TEXT UNIQUE,
      ref_by          TEXT,
      created_at      BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT,
      last_active     BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
    );

    CREATE TABLE IF NOT EXISTS categories (
      id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      name       TEXT NOT NULL,
      slug       TEXT NOT NULL UNIQUE,
      icon       TEXT,
      sort_order INTEGER DEFAULT 0,
      is_active  INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS products (
      id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      seller_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title          TEXT NOT NULL,
      description    TEXT NOT NULL,
      price          NUMERIC(12,2) NOT NULL,
      category       TEXT NOT NULL,
      subcategory    TEXT,
      images         TEXT DEFAULT '[]',
      delivery_data  TEXT,
      delivery_type  TEXT DEFAULT 'manual',
      game           TEXT,
      server         TEXT,
      status         TEXT DEFAULT 'active',
      views          INTEGER DEFAULT 0,
      sold_count     INTEGER DEFAULT 0,
      tags           TEXT DEFAULT '[]',
      is_promoted    INTEGER DEFAULT 0,
      promoted_until BIGINT,
      created_at     BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT,
      updated_at     BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
    );

    CREATE TABLE IF NOT EXISTS favorites (
      user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      created_at BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT,
      PRIMARY KEY (user_id, product_id)
    );

    CREATE SEQUENCE IF NOT EXISTS deal_number_seq START 1;

    CREATE TABLE IF NOT EXISTS deals (
      id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      deal_number      BIGINT UNIQUE DEFAULT nextval('deal_number_seq'),
      buyer_id         TEXT NOT NULL REFERENCES users(id),
      seller_id        TEXT NOT NULL REFERENCES users(id),
      product_id       TEXT NOT NULL REFERENCES products(id),
      amount           NUMERIC(12,2) NOT NULL,
      seller_amount    NUMERIC(12,2) NOT NULL,
      commission       NUMERIC(12,2) NOT NULL,
      status           TEXT DEFAULT 'pending',
      delivery_data    TEXT,
      delivered_at     BIGINT,
      completed_at     BIGINT,
      buyer_confirmed  INTEGER DEFAULT 0,
      seller_confirmed INTEGER DEFAULT 0,
      auto_complete_at BIGINT,
      dispute_reason   TEXT,
      refund_reason    TEXT,
      created_at       BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT,
      updated_at       BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id                 TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id            TEXT NOT NULL REFERENCES users(id),
      type               TEXT NOT NULL,
      amount             NUMERIC(12,2) NOT NULL,
      currency           TEXT DEFAULT 'RUB',
      status             TEXT DEFAULT 'pending',
      description        TEXT,
      deal_id            TEXT REFERENCES deals(id),
      gateway_type       TEXT,
      gateway_pay_url    TEXT,
      gateway_order_id   TEXT UNIQUE,
      balance_before     NUMERIC(12,2),
      balance_after      NUMERIC(12,2),
      created_at         BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      deal_id     TEXT NOT NULL UNIQUE REFERENCES deals(id),
      reviewer_id TEXT NOT NULL REFERENCES users(id),
      reviewed_id TEXT NOT NULL REFERENCES users(id),
      rating      INTEGER NOT NULL,
      text        TEXT,
      created_at  BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
    );

    CREATE TABLE IF NOT EXISTS messages (
      id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      sender_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      receiver_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      text        TEXT NOT NULL,
      is_read     INTEGER DEFAULT 0,
      created_at  BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
    );

    CREATE INDEX IF NOT EXISTS idx_products_category ON products(category, status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_products_seller   ON products(seller_id, status);
    CREATE INDEX IF NOT EXISTS idx_products_status   ON products(status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_deals_buyer       ON deals(buyer_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_deals_seller      ON deals(seller_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_deals_status      ON deals(status);
    CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_messages_sender   ON messages(sender_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_messages_receiver ON messages(receiver_id, is_read, created_at DESC);
  `);

  await run(`
    INSERT INTO categories (slug, name, icon, sort_order) VALUES
      ('game-accounts', 'Аккаунты', 'gamepad2', 1),
      ('game-currency', 'Валюта', 'coins', 2),
      ('items', 'Предметы', 'sword', 3),
      ('skins', 'Скины', 'palette', 4),
      ('keys', 'Ключи', 'key-round', 5),
      ('subscriptions', 'Подписки', 'star', 6),
      ('boost', 'Буст', 'rocket', 7),
      ('other', 'Прочее', 'package', 8)
    ON CONFLICT (slug) DO NOTHING;
  `);
}
