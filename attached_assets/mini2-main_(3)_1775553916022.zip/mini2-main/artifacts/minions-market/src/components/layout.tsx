import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/i18n";
import {
  Home,
  Grid3X3,
  Plus,
  MessageCircle,
  User,
  Menu,
  Gamepad2,
  Wallet,
  LogOut,
  Settings,
  Search,
  ShoppingBag,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useGetMe } from "@workspace/api-client-react";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { token, logout } = useAuth();
  const { lang, setLang, t } = useLang();
  const { data: user } = useGetMe({ query: { enabled: !!token } });

  const isActive = (path: string) => location === path || (path !== "/" && location.startsWith(path));

  const navItems = [
    { path: "/", icon: Search, label: t("home") },
    { path: "/catalog", icon: Grid3X3, label: t("catalog") },
    { path: null, icon: Plus, label: t("sell"), isSell: true },
    { path: "/messages", icon: MessageCircle, label: t("chat") },
    { path: user ? `/profile/${user.id}` : "/auth", icon: User, label: t("profile"), isProfile: true },
  ];

  return (
    <div className="min-h-[100dvh] w-full bg-[#0D0D0E] flex justify-center">
      <div className="w-full max-w-[480px] flex flex-col relative bg-[#0D0D0E] shadow-2xl">

        {/* Top Navigation */}
        <header className="h-14 flex items-center justify-between px-4 border-b border-white/5 bg-[#0D0D0E] sticky top-0 z-50">
          <Link href="/" className="font-bold text-xl text-[#FFD600] tracking-tight">
            Minions<span className="text-white opacity-60">.Market</span>
          </Link>

          <div className="flex items-center gap-1">
            {/* Language switcher */}
            <button
              onClick={() => setLang(lang === "ru" ? "en" : "ru")}
              className="text-xs font-bold px-2 py-1 rounded-lg border border-white/10 text-muted-foreground hover:text-foreground hover:border-white/20 transition-all"
            >
              {lang === "ru" ? "EN" : "RU"}
            </button>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-foreground h-9 w-9">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[280px] border-white/5 bg-[#111113] p-0">
                <SheetHeader className="p-4 border-b border-white/5 text-left">
                  <SheetTitle className="text-foreground">
                    {user ? (
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-2xl bg-[#1B1B1D] flex items-center justify-center overflow-hidden flex-shrink-0">
                          {user.avatar ? (
                            <img src={user.avatar} alt="Avatar" className="w-full h-full object-cover" />
                          ) : (
                            <span className="text-lg font-bold text-[#FFD600]">
                              {String(user.username || "?")[0].toUpperCase()}
                            </span>
                          )}
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-base font-semibold truncate">{user.username}</span>
                          <span className="text-sm text-[#FFD600] font-bold">{user.balance?.toFixed(2) || "0.00"} ₽</span>
                        </div>
                      </div>
                    ) : (
                      <span className="text-lg font-bold">{t("menu")}</span>
                    )}
                  </SheetTitle>
                </SheetHeader>

                <div className="flex flex-col py-2">
                  {[
                    { href: "/deals", icon: ShoppingBag, label: t("deals") },
                    { href: "/wallet", icon: Wallet, label: t("wallet") },
                    { href: "/settings", icon: Settings, label: t("settings") },
                  ].map(({ href, icon: Icon, label }) => (
                    <Link
                      key={href}
                      href={href}
                      className="flex items-center gap-3 px-4 py-3.5 text-foreground hover:bg-white/5 transition-colors"
                    >
                      <div className="w-9 h-9 rounded-xl bg-[#1B1B1D] flex items-center justify-center">
                        <Icon className="h-4 w-4 text-[#FFD600]" />
                      </div>
                      <span className="font-medium">{label}</span>
                    </Link>
                  ))}

                  {/* Language toggle in menu */}
                  <div className="flex items-center gap-3 px-4 py-3.5">
                    <div className="w-9 h-9 rounded-xl bg-[#1B1B1D] flex items-center justify-center">
                      <span className="text-xs font-bold text-[#FFD600]">{lang === "ru" ? "🇷🇺" : "🇬🇧"}</span>
                    </div>
                    <span className="font-medium text-foreground">{t("language")}</span>
                    <div className="ml-auto flex rounded-lg overflow-hidden border border-white/10">
                      <button
                        onClick={() => setLang("ru")}
                        className={`px-2.5 py-1 text-xs font-bold transition-colors ${lang === "ru" ? "bg-[#FFD600] text-black" : "text-muted-foreground hover:text-foreground"}`}
                      >
                        RU
                      </button>
                      <button
                        onClick={() => setLang("en")}
                        className={`px-2.5 py-1 text-xs font-bold transition-colors ${lang === "en" ? "bg-[#FFD600] text-black" : "text-muted-foreground hover:text-foreground"}`}
                      >
                        EN
                      </button>
                    </div>
                  </div>

                  <div className="mx-4 my-1 border-t border-white/5" />

                  {token ? (
                    <button
                      onClick={() => logout()}
                      className="flex items-center gap-3 px-4 py-3.5 text-red-400 hover:bg-white/5 transition-colors w-full text-left"
                    >
                      <div className="w-9 h-9 rounded-xl bg-red-500/10 flex items-center justify-center">
                        <LogOut className="h-4 w-4 text-red-400" />
                      </div>
                      <span className="font-medium">{t("logout")}</span>
                    </button>
                  ) : (
                    <Link
                      href="/auth"
                      className="flex items-center gap-3 px-4 py-3.5 text-[#FFD600] hover:bg-white/5 transition-colors"
                    >
                      <div className="w-9 h-9 rounded-xl bg-[#FFD600]/10 flex items-center justify-center">
                        <User className="h-4 w-4 text-[#FFD600]" />
                      </div>
                      <span className="font-medium">{t("login")}</span>
                    </Link>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-20">
          {children}
        </main>

        {/* Bottom Navigation */}
        <nav className="h-[60px] border-t border-white/5 bg-[#111113] flex items-center justify-around px-1 fixed bottom-0 w-full max-w-[480px] z-50">
          {navItems.map((item, i) => {
            if (item.isSell) {
              return (
                <Link key="sell" href="/sell" className="flex flex-col items-center justify-center w-14">
                  <div className="w-12 h-12 rounded-full bg-[#FFD600] flex items-center justify-center shadow-lg shadow-[#FFD600]/25 -mt-6">
                    <Plus className="h-6 w-6 text-black" strokeWidth={2.5} />
                  </div>
                </Link>
              );
            }
            const active = item.isProfile
              ? location.startsWith("/profile")
              : isActive(item.path || "/___");
            return (
              <Link
                key={i}
                href={item.path || "/sell"}
                className={`flex flex-col items-center justify-center gap-0.5 w-14 h-full transition-colors ${active ? "text-[#FFD600]" : "text-white/40"}`}
              >
                <item.icon className="h-[22px] w-[22px]" strokeWidth={active ? 2 : 1.5} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
