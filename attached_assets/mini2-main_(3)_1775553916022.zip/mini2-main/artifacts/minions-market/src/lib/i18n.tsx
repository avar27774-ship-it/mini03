import { createContext, useContext, useState, ReactNode } from "react";

type Lang = "ru" | "en";

const translations = {
  ru: {
    // Nav
    home: "Главная",
    catalog: "Каталог",
    sell: "Продать",
    chat: "Чаты",
    profile: "Профиль",
    menu: "Меню",
    // Menu items
    deals: "Сделки",
    wallet: "Кошелёк",
    settings: "Настройки",
    logout: "Выйти",
    login: "Войти / Регистрация",
    // Home
    searchPlaceholder: "Поиск игр, аккаунтов, предметов...",
    categories: "Категории",
    featured: "Популярное",
    viewAll: "Все →",
    products: "Товаров",
    dealsCount: "Сделок",
    users: "Пользователей",
    noProducts: "Нет товаров",
    // Category names
    catAccounts: "Аккаунты",
    catCurrency: "Валюта",
    catItems: "Предметы",
    catSkins: "Скины",
    catKeys: "Ключи",
    catSubscriptions: "Подписки",
    catBoost: "Буст",
    catOther: "Прочее",
    // Catalog
    allCategories: "Все",
    noProductsFound: "Товары не найдены",
    clearFilters: "Сбросить фильтры",
    sortNewest: "Новые",
    sortPriceAsc: "Дешевле",
    sortPriceDesc: "Дороже",
    sortPopular: "Популярные",
    // Product
    buy: "Купить",
    buyNow: "Купить сейчас",
    writeMessage: "Написать",
    delivery: "Доставка",
    deliveryManual: "Ручная",
    deliveryAuto: "Авто",
    views: "просмотров",
    sold: "продано",
    seller: "Продавец",
    description: "Описание",
    similar: "Похожие товары",
    // Auth
    loginTitle: "Вход",
    registerTitle: "Регистрация",
    username: "Логин",
    password: "Пароль",
    firstName: "Имя",
    loginBtn: "Войти",
    registerBtn: "Зарегистрироваться",
    // Sell
    createListing: "Новое объявление",
    title: "Название",
    titlePlaceholder: "Например: Аккаунт GTA 5 с 300 часами",
    descriptionLabel: "Описание",
    descriptionPlaceholder: "Опишите что вы продаёте...",
    price: "Цена (руб.)",
    category: "Категория",
    game: "Игра (необязательно)",
    deliveryType: "Тип доставки",
    deliveryData: "Данные доставки",
    deliveryDataPlaceholder: "Что получит покупатель (логин/пароль, ключ и т.д.)",
    tags: "Теги",
    tagsPlaceholder: "тег1, тег2, тег3",
    createBtn: "Создать объявление",
    // Deals
    myPurchases: "Мои покупки",
    mySales: "Мои продажи",
    dealNumber: "Сделка",
    amount: "Сумма",
    commission: "Комиссия",
    status: "Статус",
    noDeal: "Нет сделок",
    confirm: "Подтвердить получение",
    dispute: "Открыть спор",
    deliver: "Передать товар",
    leaveReview: "Оставить отзыв",
    deliveryDataLabel: "Данные для покупателя",
    // Deal statuses
    statusPending: "Ожидание",
    statusActive: "Активна",
    statusDelivered: "Доставлено",
    statusCompleted: "Завершена",
    statusDisputed: "Спор",
    statusRefunded: "Возврат",
    // Wallet
    balance: "Баланс",
    frozenBalance: "Заморожено",
    deposit: "Пополнить",
    withdraw: "Вывести",
    transactions: "История транзакций",
    noTransactions: "Нет транзакций",
    depositAmount: "Сумма пополнения",
    withdrawAmount: "Сумма вывода",
    withdrawMethod: "Метод вывода",
    withdrawDetails: "Реквизиты",
    // Messages
    noChats: "Нет чатов",
    typeMessage: "Написать сообщение...",
    send: "Отправить",
    // Profile
    totalSales: "Продаж",
    totalPurchases: "Покупок",
    rating: "Рейтинг",
    reviews: "Отзывы",
    noReviews: "Нет отзывов",
    editProfile: "Редактировать",
    listings: "Объявления",
    noListings: "Нет объявлений",
    sellerLevel: "Уровень продавца",
    // Settings
    settingsTitle: "Настройки",
    saveChanges: "Сохранить",
    avatarUrl: "Ссылка на аватар",
    bio: "О себе",
    language: "Язык",
    // Common
    loading: "Загрузка...",
    error: "Ошибка",
    save: "Сохранить",
    cancel: "Отмена",
    back: "Назад",
    new: "Новое",
    top: "ТОП",
  },
  en: {
    home: "Home",
    catalog: "Catalog",
    sell: "Sell",
    chat: "Chats",
    profile: "Profile",
    menu: "Menu",
    deals: "Deals",
    wallet: "Wallet",
    settings: "Settings",
    logout: "Logout",
    login: "Login / Register",
    searchPlaceholder: "Search games, accounts, items...",
    categories: "Categories",
    featured: "Featured",
    viewAll: "View all →",
    products: "Products",
    dealsCount: "Deals",
    users: "Users",
    noProducts: "No products",
    catAccounts: "Accounts",
    catCurrency: "Currency",
    catItems: "Items",
    catSkins: "Skins",
    catKeys: "Keys",
    catSubscriptions: "Subscriptions",
    catBoost: "Boost",
    catOther: "Other",
    allCategories: "All",
    noProductsFound: "No products found",
    clearFilters: "Clear filters",
    sortNewest: "Newest",
    sortPriceAsc: "Cheapest",
    sortPriceDesc: "Most expensive",
    sortPopular: "Popular",
    buy: "Buy",
    buyNow: "Buy now",
    writeMessage: "Message",
    delivery: "Delivery",
    deliveryManual: "Manual",
    deliveryAuto: "Auto",
    views: "views",
    sold: "sold",
    seller: "Seller",
    description: "Description",
    similar: "Similar products",
    loginTitle: "Login",
    registerTitle: "Register",
    username: "Username",
    password: "Password",
    firstName: "First name",
    loginBtn: "Log in",
    registerBtn: "Register",
    createListing: "New listing",
    title: "Title",
    titlePlaceholder: "E.g.: GTA 5 account with 300 hours",
    descriptionLabel: "Description",
    descriptionPlaceholder: "Describe what you are selling...",
    price: "Price (RUB)",
    category: "Category",
    game: "Game (optional)",
    deliveryType: "Delivery type",
    deliveryData: "Delivery data",
    deliveryDataPlaceholder: "What the buyer receives (login/password, key, etc.)",
    tags: "Tags",
    tagsPlaceholder: "tag1, tag2, tag3",
    createBtn: "Create listing",
    myPurchases: "My purchases",
    mySales: "My sales",
    dealNumber: "Deal",
    amount: "Amount",
    commission: "Commission",
    status: "Status",
    noDeal: "No deals",
    confirm: "Confirm receipt",
    dispute: "Open dispute",
    deliver: "Deliver item",
    leaveReview: "Leave review",
    deliveryDataLabel: "Data for buyer",
    statusPending: "Pending",
    statusActive: "Active",
    statusDelivered: "Delivered",
    statusCompleted: "Completed",
    statusDisputed: "Disputed",
    statusRefunded: "Refunded",
    balance: "Balance",
    frozenBalance: "Frozen",
    deposit: "Deposit",
    withdraw: "Withdraw",
    transactions: "Transaction history",
    noTransactions: "No transactions",
    depositAmount: "Deposit amount",
    withdrawAmount: "Withdraw amount",
    withdrawMethod: "Withdraw method",
    withdrawDetails: "Details",
    noChats: "No chats",
    typeMessage: "Type a message...",
    send: "Send",
    totalSales: "Sales",
    totalPurchases: "Purchases",
    rating: "Rating",
    reviews: "Reviews",
    noReviews: "No reviews",
    editProfile: "Edit profile",
    listings: "Listings",
    noListings: "No listings",
    sellerLevel: "Seller level",
    settingsTitle: "Settings",
    saveChanges: "Save changes",
    avatarUrl: "Avatar URL",
    bio: "About me",
    language: "Language",
    loading: "Loading...",
    error: "Error",
    save: "Save",
    cancel: "Cancel",
    back: "Back",
    new: "New",
    top: "TOP",
  },
};

export type TranslationKey = keyof typeof translations.ru;

interface LangContextType {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: TranslationKey) => string;
}

const LangContext = createContext<LangContextType | undefined>(undefined);

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    return (localStorage.getItem("lang") as Lang) || "ru";
  });

  const setLang = (l: Lang) => {
    setLangState(l);
    localStorage.setItem("lang", l);
  };

  const t = (key: TranslationKey): string => {
    return translations[lang][key] || translations.en[key] || key;
  };

  return (
    <LangContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LangContext);
  if (!ctx) throw new Error("useLang must be used inside LangProvider");
  return ctx;
}
