import { useRoute } from "wouter";
import { useGetUser, useGetUserProducts, useGetMe } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Star, MessageCircle, Package, Settings, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export function Profile() {
  const [, params] = useRoute("/profile/:id");
  const { token } = useAuth();
  const { data: me } = useGetMe({ query: { enabled: !!token } });
  
  const isMe = !params?.id || params.id === "me" || params.id === me?.id;
  const targetId = isMe && me ? me.id : params?.id;

  const { data: user, isLoading: userLoading } = useGetUser(targetId!, {
    query: { enabled: !!targetId }
  });

  const { data: productsData, isLoading: productsLoading } = useGetUserProducts(targetId!, {
    page: 1,
    limit: 50
  }, { query: { enabled: !!targetId } });

  if (userLoading) {
    return (
      <div className="p-4 flex flex-col gap-6 animate-pulse">
        <div className="flex items-center gap-4">
          <Skeleton className="w-20 h-20 rounded-full" />
          <div className="flex flex-col gap-2">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-24" />
          </div>
        </div>
        <Skeleton className="h-20 w-full" />
      </div>
    );
  }

  if (!user && targetId) {
    return <div className="p-8 text-center text-muted-foreground">User not found</div>;
  }

  if (!targetId && !token) {
    return (
      <div className="p-8 text-center flex flex-col items-center gap-4">
        <p className="text-muted-foreground">Log in to view your profile</p>
        <Button asChild><Link href="/auth">Login</Link></Button>
      </div>
    );
  }

  const joinDate = user?.createdAt ? new Date(user.createdAt).toLocaleDateString(undefined, { month: 'short', year: 'numeric' }) : 'Unknown';

  return (
    <div className="flex flex-col min-h-full bg-background pb-8">
      {/* Profile Header */}
      <div className="bg-secondary p-6 flex flex-col items-center text-center gap-4 rounded-b-[2rem]">
        <div className="relative">
          <Avatar className="w-24 h-24 border-4 border-background">
            <AvatarImage src={user?.avatar} />
            <AvatarFallback className="text-2xl bg-card text-muted-foreground">
              {user?.username?.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          {user?.isVerified && (
            <Badge className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-blue-500 hover:bg-blue-600 text-white text-[10px] px-1.5 py-0">
              Verified
            </Badge>
          )}
        </div>
        
        <div className="flex flex-col gap-1 items-center">
          <h1 className="text-2xl font-bold">{user?.username}</h1>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-3.5 h-3.5" />
            <span>Joined {joinDate}</span>
          </div>
        </div>

        {user?.bio && (
          <p className="text-sm text-muted-foreground max-w-xs">{user.bio}</p>
        )}

        <div className="flex gap-3 w-full max-w-xs mt-2">
          {isMe ? (
            <Button className="flex-1" variant="outline" asChild>
              <Link href="/settings"><Settings className="w-4 h-4 mr-2"/> Edit Profile</Link>
            </Button>
          ) : (
            <Button className="flex-1" asChild>
              <Link href={`/messages/${user?.id}`}><MessageCircle className="w-4 h-4 mr-2"/> Message</Link>
            </Button>
          )}
        </div>
      </div>

      {/* Stats Row */}
      <div className="flex justify-between px-6 py-4 border-b border-border bg-background">
        <div className="flex flex-col items-center flex-1">
          <div className="flex items-center gap-1 text-primary">
            <Star className="w-4 h-4 fill-current" />
            <span className="font-bold text-lg">{user?.rating?.toFixed(1) || '0.0'}</span>
          </div>
          <span className="text-xs text-muted-foreground">{user?.reviewCount || 0} reviews</span>
        </div>
        <div className="w-px bg-border my-2"></div>
        <div className="flex flex-col items-center flex-1">
          <span className="font-bold text-lg text-foreground">{user?.totalSales || 0}</span>
          <span className="text-xs text-muted-foreground">Sales</span>
        </div>
        <div className="w-px bg-border my-2"></div>
        <div className="flex flex-col items-center flex-1">
          <span className="font-bold text-lg text-foreground">{user?.totalPurchases || 0}</span>
          <span className="text-xs text-muted-foreground">Purchases</span>
        </div>
      </div>

      {/* Content Tabs */}
      <div className="p-4 flex flex-col gap-6">
        <div className="flex flex-col gap-3">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Package className="w-5 h-5 text-primary" /> Active Listings
          </h2>
          
          <div className="grid grid-cols-2 gap-3">
            {productsLoading ? (
              Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="aspect-square rounded-xl" />)
            ) : productsData?.products && productsData.products.length > 0 ? (
              productsData.products.map((product) => (
                <Link key={product.id} href={`/product/${product.id}`} className="bg-secondary rounded-xl overflow-hidden flex flex-col">
                  <div className="aspect-square bg-card relative">
                    {product.images?.[0] ? (
                      <img src={product.images[0]} alt={product.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        <Package className="h-8 w-8 opacity-20" />
                      </div>
                    )}
                  </div>
                  <div className="p-3 flex flex-col gap-1">
                    <span className="font-bold text-primary">${product.price.toFixed(2)}</span>
                    <span className="text-xs text-foreground line-clamp-2">{product.title}</span>
                  </div>
                </Link>
              ))
            ) : (
              <div className="col-span-2 text-center py-8 text-muted-foreground text-sm bg-secondary/50 rounded-xl">
                No active listings
              </div>
            )}
          </div>
        </div>

        {/* Reviews Section */}
        <div className="flex flex-col gap-3 mt-4">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Star className="w-5 h-5 text-primary" /> Reviews
          </h2>
          
          <div className="flex flex-col gap-3">
            {user?.reviews && user.reviews.length > 0 ? (
              user.reviews.map((review) => (
                <div key={review.id} className="bg-secondary rounded-xl p-4 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="text-[10px]">{review.reviewer?.username?.slice(0,2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm font-medium">{review.reviewer?.username}</span>
                    </div>
                    <div className="flex text-primary">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-current' : 'opacity-20'}`} />
                      ))}
                    </div>
                  </div>
                  {review.text && <p className="text-sm text-muted-foreground mt-1">{review.text}</p>}
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground text-sm bg-secondary/50 rounded-xl">
                No reviews yet
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
