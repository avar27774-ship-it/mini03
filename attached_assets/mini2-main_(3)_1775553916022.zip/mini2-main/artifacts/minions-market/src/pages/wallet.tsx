import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useGetBalance, useListTransactions, useDeposit, useWithdraw } from "@workspace/api-client-react";
import { Wallet as WalletIcon, ArrowUpRight, ArrowDownLeft, Plus, Download, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

export function Wallet() {
  const [, setLocation] = useLocation();
  const { token } = useAuth();
  const { toast } = useToast();
  
  const [depositOpen, setDepositOpen] = useState(false);
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("crypto");
  const [details, setDetails] = useState("");

  const { data: balanceData, isLoading: balanceLoading } = useGetBalance({ query: { enabled: !!token } });
  const { data: txData, isLoading: txLoading } = useListTransactions({ limit: 20 }, { query: { enabled: !!token } });
  
  const depositMut = useDeposit();
  const withdrawMut = useWithdraw();

  if (!token) {
    setLocation("/auth");
    return null;
  }

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(Number(amount))) return;
    
    depositMut.mutate({ data: { amount: Number(amount) } }, {
      onSuccess: (res) => {
        setDepositOpen(false);
        setAmount("");
        // In a real app, redirect to res.payUrl
        toast({ title: "Redirecting to payment gateway...", description: "Simulated for now." });
      },
      onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(Number(amount)) || !details) return;
    
    withdrawMut.mutate({ data: { amount: Number(amount), method, details } }, {
      onSuccess: () => {
        setWithdrawOpen(false);
        setAmount("");
        setDetails("");
        toast({ title: "Withdrawal requested successfully" });
      },
      onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  return (
    <div className="flex flex-col min-h-full bg-background pb-8">
      {/* Balance Card */}
      <div className="bg-card border-b border-border p-6 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-2 text-muted-foreground mb-2">
          <WalletIcon className="w-5 h-5" />
          <span className="font-medium">Total Balance</span>
        </div>
        
        {balanceLoading ? (
          <Skeleton className="h-12 w-48 mb-2" />
        ) : (
          <div className="text-5xl font-black text-primary tracking-tight">
            ${balanceData?.balance?.toFixed(2) || "0.00"}
          </div>
        )}
        
        {!balanceLoading && balanceData?.frozenBalance && balanceData.frozenBalance > 0 ? (
          <div className="flex items-center gap-1 text-sm text-muted-foreground mt-2">
            <AlertCircle className="w-4 h-4" />
            <span>${balanceData.frozenBalance.toFixed(2)} on hold in active deals</span>
          </div>
        ) : null}

        <div className="grid grid-cols-2 gap-3 mt-8">
          <Dialog open={depositOpen} onOpenChange={setDepositOpen}>
            <DialogTrigger asChild>
              <Button className="w-full h-12 text-base font-bold bg-secondary text-foreground hover:bg-secondary/80 border-none">
                <ArrowDownLeft className="w-5 h-5 mr-2 text-green-500" /> Top Up
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[400px] bg-card border-border">
              <DialogHeader>
                <DialogTitle>Add Funds</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleDeposit} className="flex flex-col gap-4 mt-4">
                <div className="flex flex-col gap-2">
                  <Label>Amount ($)</Label>
                  <Input 
                    type="number" 
                    min="1" 
                    step="1" 
                    value={amount} 
                    onChange={e => setAmount(e.target.value)}
                    className="bg-secondary border-none h-12 text-lg font-bold"
                    placeholder="10.00"
                  />
                </div>
                <Button type="submit" className="w-full h-12 text-base font-bold" disabled={depositMut.isPending}>
                  {depositMut.isPending ? "Processing..." : "Continue to Payment"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={withdrawOpen} onOpenChange={setWithdrawOpen}>
            <DialogTrigger asChild>
              <Button className="w-full h-12 text-base font-bold bg-secondary text-foreground hover:bg-secondary/80 border-none">
                <ArrowUpRight className="w-5 h-5 mr-2 text-destructive" /> Withdraw
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[400px] bg-card border-border">
              <DialogHeader>
                <DialogTitle>Withdraw Funds</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleWithdraw} className="flex flex-col gap-4 mt-4">
                <div className="flex flex-col gap-2">
                  <Label>Amount ($)</Label>
                  <Input 
                    type="number" 
                    min="5" 
                    step="1" 
                    value={amount} 
                    onChange={e => setAmount(e.target.value)}
                    className="bg-secondary border-none h-12 text-lg font-bold"
                    placeholder="50.00"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label>Method</Label>
                  <select 
                    className="flex h-12 w-full items-center justify-between rounded-md bg-secondary px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 border-none"
                    value={method}
                    onChange={e => setMethod(e.target.value)}
                  >
                    <option value="crypto">Crypto (USDT TRC20)</option>
                    <option value="card">Bank Card</option>
                  </select>
                </div>
                <div className="flex flex-col gap-2">
                  <Label>Payment Details</Label>
                  <Input 
                    value={details} 
                    onChange={e => setDetails(e.target.value)}
                    className="bg-secondary border-none h-12"
                    placeholder="Wallet address or card number"
                  />
                </div>
                <Button type="submit" className="w-full h-12 text-base font-bold" disabled={withdrawMut.isPending}>
                  {withdrawMut.isPending ? "Processing..." : "Request Withdrawal"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Transactions */}
      <div className="flex flex-col p-4 gap-4">
        <h2 className="font-bold text-lg">Recent Transactions</h2>
        
        <div className="flex flex-col gap-3">
          {txLoading ? (
            Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)
          ) : txData?.transactions && txData.transactions.length > 0 ? (
            txData.transactions.map((tx) => {
              const isPositive = ['deposit', 'sale_revenue'].includes(tx.type);
              const Icon = isPositive ? Plus : ArrowUpRight;
              const color = isPositive ? 'text-green-500' : 'text-foreground';
              const sign = isPositive ? '+' : '-';
              
              return (
                <div key={tx.id} className="flex items-center justify-between bg-secondary/50 p-3 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full bg-background flex items-center justify-center ${color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-sm capitalize">{tx.type.replace('_', ' ')}</span>
                      <span className="text-xs text-muted-foreground">
                        {tx.createdAt ? format(new Date(tx.createdAt), 'MMM d, HH:mm') : ''}
                      </span>
                    </div>
                  </div>
                  <div className={`font-bold ${color}`}>
                    {sign}${Math.abs(tx.amount).toFixed(2)}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-8 text-muted-foreground text-sm">
              No transactions yet
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
