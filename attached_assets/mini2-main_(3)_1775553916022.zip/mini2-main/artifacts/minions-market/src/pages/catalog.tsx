import { useState } from "react";
import { useLocation, useSearch, Link } from "wouter";
import { useListProducts, useListCategories } from "@workspace/api-client-react";
import { useLang } from "@/lib/i18n";
import { Search, ChevronLeft, ChevronRight, Gamepad2, Star } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export function Catalog() {
  const searchStr = useSearch();
  const [, setLocation] = useLocation();
  const { t } = useLang();
  const query = new URLSearchParams(searchStr);

  const category = query.get("category") || undefined;
  const search = query.get("search") || undefined;
  const sort = query.get("sort") || "newest";
  const page = parseInt(query.get("page") || "1");
  const limit = 20;

  const [searchInput, setSearchInput] = useState(search || "");

  const { data: categories } = useListCategories();
  const { data: productsData, isLoading } = useListProducts({ category, search, sort, page, limit });

  const updateFilters = (key: string, value: string | null) => {
    const q = new URLSearchParams(searchStr);
    if (value) q.set(key, value); else q.delete(key);
    if (key !== "page") q.set("page", "1");
    setLocation(`/catalog?${q.toString()}`);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateFilters("search", searchInput || null);
  };

  const sortOptions = [
    { value: "newest", label: t("sortNewest") },
    { value: "price_asc", label: t("sortPriceAsc") },
    { value: "price_desc", label: t("sortPriceDesc") },
    { value: "popular", label: t("sortPopular") },
  ];

  return (
    <div className="flex flex-col min-h-full">
      {/* Sticky filter bar */}
      <div className="sticky top-14 z-40 bg-[#0D0D0E] border-b border-white/5 px-4 pt-3 pb-2 flex flex-col gap-2.5">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/25" />
          <input
            placeholder={t("searchPlaceholder")}
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="w-full pl-10 h-10 bg-[#1B1B1D] border border-white/5 rounded-xl text-[14px] text-white placeholder:text-white/25 outline-none focus:border-[#FFD600]/30 transition-colors"
          />
        </form>

        {/* Category pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button
            onClick={() => updateFilters("category", null)}
            className={`flex-shrink-0 px-3.5 h-7 rounded-full text-xs font-bold transition-colors ${
              !category ? "bg-[#FFD600] text-black" : "bg-[#1B1B1D] text-white/50 hover:text-white"
            }`}
          >
            {t("allCategories")}
          </button>
          {categories?.map((cat) => (
            <button
              key={cat.id}
              onClick={() => updateFilters("category", cat.slug)}
              className={`flex-shrink-0 px-3.5 h-7 rounded-full text-xs font-bold transition-colors ${
                category === cat.slug ? "bg-[#FFD600] text-black" : "bg-[#1B1B1D] text-white/50 hover:text-white"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Sort + count */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-white/30">
            {productsData?.total ?? 0} {t("products").toLowerCase()}
          </span>
          <select
            value={sort}
            onChange={(e) => updateFilters("sort", e.target.value)}
            className="text-xs bg-[#1B1B1D] border border-white/5 rounded-lg px-2.5 py-1.5 text-white/60 outline-none"
          >
            {sortOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      </div>

      {/* Product grid */}
      <div className="p-3">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-2.5">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex flex-col gap-2">
                <Skeleton className="w-full aspect-square rounded-2xl bg-[#1B1B1D]" />
                <Skeleton className="h-3 w-3/4 bg-[#1B1B1D]" />
                <Skeleton className="h-3 w-1/2 bg-[#1B1B1D]" />
              </div>
            ))}
          </div>
        ) : productsData?.products.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-white/20 gap-4">
            <Gamepad2 className="w-14 h-14" />
            <p className="text-sm">{t("noProductsFound")}</p>
            <button
              onClick={() => setLocation("/catalog")}
              className="px-4 py-2 border border-white/10 rounded-xl text-xs text-white/40 hover:text-white/60 transition-colors"
            >
              {t("clearFilters")}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {productsData?.products.map((product) => (
              <Link
                key={product.id}
                href={`/product/${product.id}`}
                className="bg-[#1B1B1D] rounded-2xl overflow-hidden flex flex-col border border-white/5 active:scale-95 transition-transform"
              >
                <div className="aspect-square bg-[#111113] relative">
                  {product.images?.[0] ? (
                    <img src={product.images[0]} alt={product.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-4xl font-black text-white/8">
                        {String(product.title || "?")[0].toUpperCase()}
                      </span>
                    </div>
                  )}
                  {product.isPromoted && (
                    <div className="absolute top-1.5 left-1.5 bg-[#FFD600] text-black text-[9px] font-black px-1.5 py-0.5 rounded-full">
                      {t("top")}
                    </div>
                  )}
                </div>
                <div className="p-2.5 flex flex-col gap-1">
                  <span className="text-[15px] font-black text-[#FFD600]">{product.price?.toFixed(0)} ₽</span>
                  <span className="text-[12px] text-white/70 line-clamp-2 leading-tight">{product.title}</span>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-[10px] text-white/30 truncate">{product.seller?.username}</span>
                    {product.seller?.rating ? (
                      <div className="flex items-center gap-0.5">
                        <Star className="h-2.5 w-2.5 text-[#FFD600] fill-[#FFD600]" />
                        <span className="text-[10px] text-white/40">{Number(product.seller.rating).toFixed(1)}</span>
                      </div>
                    ) : null}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

        {/* Pagination */}
        {productsData && (productsData.totalPages ?? 0) > 1 && (
          <div className="flex items-center justify-center gap-4 mt-6 pb-4">
            <button
              onClick={() => updateFilters("page", (page - 1).toString())}
              disabled={page <= 1}
              className="w-9 h-9 rounded-xl bg-[#1B1B1D] flex items-center justify-center text-white/40 disabled:opacity-30 hover:text-white transition-colors"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-sm text-white/40">{page} / {productsData.totalPages}</span>
            <button
              onClick={() => updateFilters("page", (page + 1).toString())}
              disabled={page >= (productsData.totalPages ?? 1)}
              className="w-9 h-9 rounded-xl bg-[#1B1B1D] flex items-center justify-center text-white/40 disabled:opacity-30 hover:text-white transition-colors"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
