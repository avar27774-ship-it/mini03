import { useRoute, useLocation, Link } from "wouter";
import { useGetProduct, useCreateDeal, useListCategories } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Gamepad2, Star, User, ChevronLeft, Shield, Eye, ShoppingCart } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function Product() {
  const [, params] = useRoute("/product/:id");
  const [, setLocation] = useLocation();
  const { token } = useAuth();
  const { toast } = useToast();
  const id = params?.id;

  const { data: product, isLoading } = useGetProduct(id!, {
    query: { enabled: !!id }
  });

  const { data: categories } = useListCategories();
  
  const createDeal = useCreateDeal();

  const handleBuy = () => {
    if (!token) {
      toast({ title: "Please login to purchase", variant: "destructive" });
      setLocation("/auth");
      return;
    }

    if (!id) return;

    createDeal.mutate({ data: { productId: id } }, {
      onSuccess: (deal) => {
        toast({ title: "Order created successfully!" });
        setLocation(`/deals`);
      },
      onError: (err: any) => {
        toast({ 
          title: "Failed to create order", 
          description: err.message,
          variant: "destructive" 
        });
      }
    });
  };

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4 p-4">
        <Skeleton className="w-full aspect-video rounded-xl" />
        <Skeleton className="h-8 w-3/4" />
        <Skeleton className="h-6 w-1/4" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] p-4 text-center">
        <h2 className="text-xl font-bold mb-2">Product not found</h2>
        <Button onClick={() => setLocation("/catalog")}>Back to catalog</Button>
      </div>
    );
  }

  const category = categories?.find(c => c.slug === product.category);

  return (
    <div className="flex flex-col min-h-full pb-24 relative">
      {/* Header Back */}
      <div className="absolute top-4 left-4 z-10">
        <Button variant="secondary" size="icon" className="rounded-full bg-background/80 backdrop-blur" onClick={() => window.history.back()}>
          <ChevronLeft className="h-5 w-5" />
        </Button>
      </div>

      {/* Image */}
      <div className="w-full aspect-video bg-card relative">
        {product.images?.[0] ? (
          <img src={product.images[0]} alt={product.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <Gamepad2 className="h-16 w-16 opacity-20" />
          </div>
        )}
      </div>

      <div className="flex flex-col gap-6 p-4">
        {/* Title & Price */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="secondary" className="text-xs bg-primary/10 text-primary border-primary/20">
              {category?.name || product.category}
            </Badge>
            {product.deliveryType && (
              <Badge variant="outline" className="text-xs">
                {product.deliveryType === 'auto' ? 'Auto Delivery' : 'Manual Delivery'}
              </Badge>
            )}
          </div>
          <h1 className="text-2xl font-bold text-foreground leading-tight">{product.title}</h1>
          <div className="text-3xl font-black text-primary">${product.price.toFixed(2)}</div>
        </div>

        {/* Seller Info */}
        <div className="bg-secondary rounded-xl p-4 flex items-center gap-4">
          <Link href={`/profile/${product.seller?.id}`} className="w-12 h-12 rounded-full bg-card overflow-hidden shrink-0 flex items-center justify-center">
            {product.seller?.avatar ? (
              <img src={product.seller.avatar} alt="Seller" className="w-full h-full object-cover" />
            ) : (
              <User className="h-6 w-6 text-muted-foreground" />
            )}
          </Link>
          <div className="flex flex-col flex-1">
            <Link href={`/profile/${product.seller?.id}`} className="font-bold text-base hover:underline">{product.seller?.username}</Link>
            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
              <div className="flex items-center gap-1 text-primary">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span className="font-medium text-foreground">{product.seller?.rating?.toFixed(1) || 'New'}</span>
              </div>
              <span>•</span>
              <span>{product.seller?.totalSales || 0} sales</span>
            </div>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link href={`/messages/${product.seller?.id}`}>Write</Link>
          </Button>
        </div>

        {/* Description */}
        <div className="flex flex-col gap-3">
          <h3 className="text-lg font-bold">Description</h3>
          <div className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">
            {product.description || "No description provided."}
          </div>
        </div>

        {/* Tags */}
        {product.tags && product.tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {product.tags.map(tag => (
              <Badge key={tag} variant="secondary" className="bg-card">{tag}</Badge>
            ))}
          </div>
        )}

        {/* Meta Info */}
        <div className="flex items-center gap-4 text-xs text-muted-foreground pt-4 border-t border-border">
          <div className="flex items-center gap-1.5">
            <Eye className="w-4 h-4" />
            <span>{product.views || 0} views</span>
          </div>
          <div className="flex items-center gap-1.5">
            <ShoppingCart className="w-4 h-4" />
            <span>{product.soldCount || 0} sold</span>
          </div>
          <div className="flex items-center gap-1.5 ml-auto">
            <Shield className="w-4 h-4 text-green-500" />
            <span className="text-green-500">Secure Deal</span>
          </div>
        </div>
      </div>

      {/* Fixed Bottom Action */}
      <div className="fixed bottom-16 w-full max-w-[480px] bg-background/80 backdrop-blur border-t border-border p-4 z-40">
        <Button 
          className="w-full h-12 text-lg font-bold" 
          onClick={handleBuy}
          disabled={createDeal.isPending || product.sellerId === token?.split('.')[0] /* Basic check, real check requires full decoded user */}
        >
          {createDeal.isPending ? "Processing..." : `Buy for $${product.price.toFixed(2)}`}
        </Button>
      </div>
    </div>
  );
}
