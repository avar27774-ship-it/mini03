import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useGetMe, useUpdateProfile } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { LogOut, Save, User as UserIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const profileSchema = z.object({
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  bio: z.string().max(160, "Bio too long").optional(),
  avatar: z.string().url("Must be a valid URL").optional().or(z.literal(''))
});

type ProfileValues = z.infer<typeof profileSchema>;

export function Settings() {
  const [, setLocation] = useLocation();
  const { token, logout } = useAuth();
  const { toast } = useToast();

  const { data: user, isLoading } = useGetMe({ query: { enabled: !!token } });
  const updateProfile = useUpdateProfile();

  const form = useForm<ProfileValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      bio: "",
      avatar: ""
    }
  });

  useEffect(() => {
    if (user) {
      form.reset({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        bio: user.bio || "",
        avatar: user.avatar || ""
      });
    }
  }, [user, form]);

  if (!token) {
    setLocation("/auth");
    return null;
  }

  const onSubmit = (values: ProfileValues) => {
    updateProfile.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Profile updated successfully" });
      },
      onError: (err: any) => {
        toast({ title: "Failed to update profile", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  if (isLoading) return <div className="p-4">Loading...</div>;

  return (
    <div className="flex flex-col p-4 gap-6 min-h-full pb-8">
      <h1 className="text-2xl font-bold">Settings</h1>

      <div className="bg-secondary/50 rounded-xl p-4 flex items-center gap-4 border border-border">
        <Avatar className="w-16 h-16 border-2 border-card">
          <AvatarImage src={form.watch("avatar")} />
          <AvatarFallback className="bg-card"><UserIcon className="w-8 h-8 text-muted-foreground" /></AvatarFallback>
        </Avatar>
        <div className="flex flex-col">
          <span className="text-sm text-muted-foreground uppercase tracking-wider font-mono">Username</span>
          <span className="text-xl font-bold">{user?.username}</span>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col gap-4">
          
          <FormField
            control={form.control}
            name="avatar"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Avatar URL</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/image.png" className="bg-secondary border-none h-12" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>First Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John" className="bg-secondary border-none h-12" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="lastName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Last Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Doe" className="bg-secondary border-none h-12" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="bio"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bio</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Tell buyers a bit about yourself..." 
                    className="bg-secondary border-none min-h-[100px] resize-none" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {user?.refCode && (
            <div className="flex flex-col gap-2 mt-2">
              <FormLabel>Referral Code</FormLabel>
              <div className="h-12 bg-secondary/50 rounded-md flex items-center px-4 font-mono text-primary text-sm border border-border select-all">
                {user.refCode}
              </div>
            </div>
          )}

          <Button type="submit" className="w-full h-12 text-base font-bold mt-4" disabled={updateProfile.isPending}>
            <Save className="w-4 h-4 mr-2" />
            {updateProfile.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </form>
      </Form>

      <div className="mt-8 pt-6 border-t border-border">
        <Button variant="destructive" className="w-full h-12 text-base font-bold bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground border-none" onClick={handleLogout}>
          <LogOut className="w-4 h-4 mr-2" /> Logout
        </Button>
      </div>
    </div>
  );
}
