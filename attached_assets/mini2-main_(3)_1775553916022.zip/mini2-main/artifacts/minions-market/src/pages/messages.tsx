import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { useAuth } from "@/lib/auth";
import { useListChats, useGetMessages, useSendMessage, useGetMe } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, ArrowLeft, MessageCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export function Messages() {
  const [, params] = useRoute("/messages/:userId");
  const [, setLocation] = useLocation();
  const { token } = useAuth();
  
  const selectedUserId = params?.userId;
  const [text, setText] = useState("");

  const { data: me } = useGetMe({ query: { enabled: !!token } });
  const { data: chats, isLoading: chatsLoading } = useListChats({ query: { enabled: !!token, refetchInterval: 10000 } });
  
  const { data: messages, isLoading: messagesLoading } = useGetMessages(selectedUserId!, { page: 1 }, { 
    query: { enabled: !!selectedUserId && !!token, refetchInterval: 3000 } 
  });

  const sendMessageMut = useSendMessage();

  if (!token) {
    setLocation("/auth");
    return null;
  }

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !selectedUserId) return;

    sendMessageMut.mutate({ data: { text } }, {
      onSuccess: () => setText("")
    });
  };

  // If mobile and a chat is selected, show thread view
  if (selectedUserId) {
    const chatUser = chats?.find(c => c.userId === selectedUserId)?.user;
    
    return (
      <div className="flex flex-col h-[calc(100vh-120px)] bg-background">
        {/* Header */}
        <div className="h-14 border-b border-border flex items-center px-4 gap-3 bg-card shrink-0">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/messages")} className="-ml-2">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <Avatar className="w-8 h-8">
            <AvatarImage src={chatUser?.avatar} />
            <AvatarFallback>{chatUser?.username?.slice(0,2).toUpperCase() || 'U'}</AvatarFallback>
          </Avatar>
          <span className="font-bold">{chatUser?.username || 'User'}</span>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col-reverse gap-4">
          {messagesLoading ? (
            <div className="flex flex-col gap-4 w-full">
              <Skeleton className="h-12 w-2/3 self-start rounded-xl" />
              <Skeleton className="h-16 w-3/4 self-end rounded-xl" />
              <Skeleton className="h-10 w-1/2 self-start rounded-xl" />
            </div>
          ) : messages && messages.length > 0 ? (
            [...messages].map((msg) => {
              const isMine = msg.senderId === me?.id;
              return (
                <div key={msg.id} className={`max-w-[85%] flex flex-col gap-1 ${isMine ? 'self-end items-end' : 'self-start items-start'}`}>
                  <div className={`px-4 py-2.5 rounded-2xl text-sm ${isMine ? 'bg-primary text-primary-foreground rounded-tr-sm' : 'bg-secondary text-foreground rounded-tl-sm'}`}>
                    {msg.text}
                  </div>
                  <span className="text-[10px] text-muted-foreground px-1">
                    {msg.createdAt ? format(new Date(msg.createdAt), 'HH:mm') : ''}
                  </span>
                </div>
              );
            })
          ) : (
            <div className="text-center py-10 text-muted-foreground text-sm m-auto">
              Send a message to start chatting
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-3 bg-card border-t border-border shrink-0">
          <form onSubmit={handleSend} className="flex gap-2">
            <Input 
              value={text}
              onChange={e => setText(e.target.value)}
              placeholder="Type a message..."
              className="bg-secondary border-none rounded-full h-10 px-4"
            />
            <Button type="submit" size="icon" className="rounded-full shrink-0 h-10 w-10" disabled={!text.trim() || sendMessageMut.isPending}>
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    );
  }

  // Chat List View
  return (
    <div className="flex flex-col h-full bg-background p-4 gap-4">
      <h1 className="text-2xl font-bold">Messages</h1>
      
      <div className="flex flex-col gap-2">
        {chatsLoading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 p-3">
              <Skeleton className="w-12 h-12 rounded-full shrink-0" />
              <div className="flex flex-col gap-2 flex-1">
                <Skeleton className="h-4 w-1/3" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            </div>
          ))
        ) : chats && chats.length > 0 ? (
          chats.map((chat) => (
            <div 
              key={chat.userId}
              onClick={() => setLocation(`/messages/${chat.userId}`)}
              className="flex items-center gap-3 p-3 bg-secondary/50 rounded-xl cursor-pointer hover:bg-secondary transition-colors"
            >
              <Avatar className="w-12 h-12 border border-border shrink-0">
                <AvatarImage src={chat.user?.avatar} />
                <AvatarFallback className="bg-card">{chat.user?.username?.slice(0,2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex flex-col flex-1 overflow-hidden">
                <div className="flex justify-between items-center mb-0.5">
                  <span className="font-bold text-sm truncate">{chat.user?.username}</span>
                  <span className="text-[10px] text-muted-foreground shrink-0">
                    {chat.lastMessage?.createdAt ? format(new Date(chat.lastMessage.createdAt), 'HH:mm') : ''}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground truncate">
                  {chat.lastMessage?.text || 'No messages'}
                </span>
              </div>
              {chat.unreadCount ? (
                <div className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center shrink-0">
                  {chat.unreadCount}
                </div>
              ) : null}
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground gap-4">
            <MessageCircle className="w-12 h-12 opacity-20" />
            <p>No active chats</p>
          </div>
        )}
      </div>
    </div>
  );
}
