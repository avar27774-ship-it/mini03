import { useState } from "react";
import { useGetProductsStats, useGetFeaturedProducts, useListCategories } from "@workspace/api-client-react";
import { Link, useLocation } from "wouter";
import { useLang } from "@/lib/i18n";
import { Search, Star } from "lucide-react";

// App-icon style category config: gradient colors + emoji/letter
const categoryConfig: Record<string, { from: string; to: string; emoji: string }> = {
  "game-accounts": { from: "#3B82F6", to: "#1D4ED8", emoji: "A" },
  "game-currency":  { from: "#F59E0B", to: "#D97706", emoji: "₽" },
  "items":          { from: "#EF4444", to: "#B91C1C", emoji: "⚔" },
  "skins":          { from: "#8B5CF6", to: "#6D28D9", emoji: "✦" },
  "keys":           { from: "#10B981", to: "#047857", emoji: "🗝" },
  "subscriptions":  { from: "#EC4899", to: "#BE185D", emoji: "★" },
  "boost":          { from: "#F97316", to: "#C2410C", emoji: "⚡" },
  "other":          { from: "#6B7280", to: "#374151", emoji: "+" },
};

const catNameMap: Record<string, "catAccounts" | "catCurrency" | "catItems" | "catSkins" | "catKeys" | "catSubscriptions" | "catBoost" | "catOther"> = {
  "game-accounts":   "catAccounts",
  "game-currency":   "catCurrency",
  "items":           "catItems",
  "skins":           "catSkins",
  "keys":            "catKeys",
  "subscriptions":   "catSubscriptions",
  "boost":           "catBoost",
  "other":           "catOther",
};

export function Home() {
  const { t } = useLang();
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");

  const { data: stats } = useGetProductsStats();
  const { data: categories } = useListCategories();
  const { data: featured } = useGetFeaturedProducts();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) setLocation(`/catalog?search=${encodeURIComponent(search.trim())}`);
  };

  return (
    <div className="flex flex-col">
      {/* Search bar */}
      <div className="px-4 pt-4 pb-2">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={t("searchPlaceholder")}
            className="w-full pl-10 pr-4 h-12 bg-[#1B1B1D] border border-white/5 rounded-2xl text-[15px] text-white placeholder:text-white/25 outline-none focus:border-[#FFD600]/40 transition-colors"
          />
        </form>
      </div>

      {/* Stats bar */}
      {stats && (
        <div className="px-4 py-3">
          <div className="flex gap-2">
            {[
              { val: stats.totalProducts, label: t("products") },
              { val: stats.totalDeals, label: t("dealsCount"), yellow: true },
              { val: stats.totalUsers, label: t("users") },
            ].map(({ val, label, yellow }) => (
              <div key={label} className="flex-1 bg-[#1B1B1D] rounded-2xl p-3 text-center">
                <div className={`text-xl font-black ${yellow ? "text-[#FFD600]" : "text-white"}`}>
                  {val?.toLocaleString() ?? 0}
                </div>
                <div className="text-[10px] text-white/30 uppercase tracking-widest mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Categories */}
      <div className="px-4 pt-2 pb-1">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[17px] font-bold text-white">{t("categories")}</span>
          <Link href="/catalog" className="text-[13px] text-[#FFD600] font-medium">{t("viewAll")}</Link>
        </div>

        <div className="grid grid-cols-4 gap-2.5">
          {categories?.map((cat) => {
            const cfg = categoryConfig[cat.slug] || { from: "#6B7280", to: "#374151", emoji: cat.name[0] };
            const nameKey = catNameMap[cat.slug];
            const displayName = nameKey ? t(nameKey) : cat.name;

            return (
              <Link
                key={cat.id}
                href={`/catalog?category=${cat.slug}`}
                className="flex flex-col items-center gap-1.5"
              >
                {/* App icon */}
                <div
                  className="w-full aspect-square rounded-[22px] flex items-center justify-center shadow-lg relative overflow-hidden"
                  style={{
                    background: `linear-gradient(145deg, ${cfg.from}, ${cfg.to})`,
                    boxShadow: `0 4px 16px ${cfg.from}40`,
                  }}
                >
                  {/* Gloss overlay */}
                  <div
                    className="absolute inset-0 rounded-[22px] opacity-20"
                    style={{
                      background: "linear-gradient(135deg, rgba(255,255,255,0.3) 0%, transparent 50%)",
                    }}
                  />
                  <span className="text-2xl font-black text-white drop-shadow-sm z-10 leading-none">
                    {cfg.emoji}
                  </span>
                </div>
                <span className="text-[11px] text-white/60 font-medium text-center leading-tight line-clamp-1 w-full text-center">
                  {displayName}
                </span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Featured products */}
      <div className="px-4 pt-4 pb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[17px] font-bold text-white">{t("featured")}</span>
          <Link href="/catalog" className="text-[13px] text-[#FFD600] font-medium">{t("viewAll")}</Link>
        </div>

        {(!featured || featured.length === 0) ? (
          <div className="text-center py-8 text-white/25 text-sm">{t("noProducts")}</div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {featured.slice(0, 6).map((product) => (
              <Link
                key={product.id}
                href={`/product/${product.id}`}
                data-testid={`card-product-${product.id}`}
                className="bg-[#1B1B1D] rounded-2xl overflow-hidden flex flex-col border border-white/5 active:scale-95 transition-transform"
              >
                {/* Image */}
                <div className="aspect-square bg-[#111113] relative">
                  {product.images?.[0] ? (
                    <img src={product.images[0]} alt={product.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-4xl font-black text-white/10">
                        {String(product.title || "?")[0].toUpperCase()}
                      </span>
                    </div>
                  )}
                  {product.isPromoted && (
                    <div className="absolute top-2 left-2 bg-[#FFD600] text-black text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                      {t("top")}
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="p-2.5 flex flex-col gap-1">
                  <span className="text-[15px] font-black text-[#FFD600] leading-none">
                    {product.price?.toFixed(0)} ₽
                  </span>
                  <span className="text-[12px] text-white/80 line-clamp-2 leading-tight">{product.title}</span>

                  {product.seller && (
                    <div className="flex items-center gap-1.5 mt-1">
                      <div className="w-4 h-4 rounded-full bg-[#111113] flex items-center justify-center overflow-hidden flex-shrink-0">
                        {product.seller.avatar ? (
                          <img src={product.seller.avatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-[8px] font-bold text-white/40">
                            {String(product.seller.username || "?")[0].toUpperCase()}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-white/35 truncate">{product.seller.username}</span>
                      {product.seller.rating && (
                        <div className="ml-auto flex items-center gap-0.5">
                          <Star className="h-2.5 w-2.5 text-[#FFD600] fill-[#FFD600]" />
                          <span className="text-[10px] text-white/40">{Number(product.seller.rating).toFixed(1)}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
