import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useCreateProduct, useListCategories } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const formSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.coerce.number().positive("Price must be positive"),
  category: z.string().min(1, "Please select a category"),
  deliveryType: z.enum(["manual", "auto"]),
  deliveryData: z.string().optional(),
  game: z.string().optional(),
  tags: z.string().optional()
});

type FormValues = z.infer<typeof formSchema>;

export function Sell() {
  const [, setLocation] = useLocation();
  const { token } = useAuth();
  const { toast } = useToast();
  const { data: categories } = useListCategories();
  const createProduct = useCreateProduct();

  // Redirect if not logged in
  if (!token) {
    setLocation("/auth");
    return null;
  }

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      price: undefined as unknown as number,
      category: "",
      deliveryType: "manual",
      deliveryData: "",
      game: "",
      tags: ""
    }
  });

  const deliveryType = form.watch("deliveryType");

  const onSubmit = (values: FormValues) => {
    const payload = {
      ...values,
      tags: values.tags ? values.tags.split(',').map(t => t.trim()).filter(Boolean) : []
    };

    createProduct.mutate({ data: payload }, {
      onSuccess: () => {
        toast({ title: "Product listed successfully!" });
        setLocation("/profile/me");
      },
      onError: (err: any) => {
        toast({
          title: "Failed to list product",
          description: err.message,
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="p-4 flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Create Listing</h1>
        <p className="text-sm text-muted-foreground mt-1">Sell your items, accounts, or services</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Title</FormLabel>
                <FormControl>
                  <Input placeholder="e.g. Max Level Account with rare skins" className="bg-secondary border-none h-12" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Price ($)</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" min="0.1" placeholder="0.00" className="bg-secondary border-none h-12 font-bold text-primary text-lg" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-secondary border-none h-12">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories?.map(c => (
                        <SelectItem key={c.id} value={c.slug}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Describe what you are selling in detail..." 
                    className="bg-secondary border-none min-h-[120px] resize-none" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="p-4 bg-secondary rounded-xl flex flex-col gap-4">
            <h3 className="font-semibold text-sm">Delivery Method</h3>
            <FormField
              control={form.control}
              name="deliveryType"
              render={({ field }) => (
                <FormItem>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-background border-none h-12">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="manual">Manual Delivery (Chat)</SelectItem>
                      <SelectItem value="auto">Automatic Delivery</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {deliveryType === "auto" && (
              <FormField
                control={form.control}
                name="deliveryData"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground">Data to deliver automatically to buyer after payment</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Login: password / API Key / Download Link..." 
                        className="bg-background border-none min-h-[80px] font-mono text-sm" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="game"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Game (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Roblox" className="bg-secondary border-none h-12" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="tags"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tags (Comma separated)</FormLabel>
                  <FormControl>
                    <Input placeholder="rare, max level" className="bg-secondary border-none h-12" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <Button type="submit" className="w-full h-14 text-lg font-bold mt-4" disabled={createProduct.isPending}>
            {createProduct.isPending && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
            Publish Listing
          </Button>

        </form>
      </Form>
    </div>
  );
}
