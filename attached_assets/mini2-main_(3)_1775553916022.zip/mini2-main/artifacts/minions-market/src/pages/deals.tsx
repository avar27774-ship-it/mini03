import { useState } from "react";
import { useLocation } from "wouter";
import { 
  useListDeals, 
  useGetDeal, 
  useConfirmDeal, 
  useDisputeDeal, 
  useDeliverDeal, 
  useReviewDeal 
} from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Package, Clock, CheckCircle2, AlertCircle, MessageCircle, Star } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export function Deals() {
  const [, setLocation] = useLocation();
  const { token } = useAuth();
  const { toast } = useToast();
  
  const [role, setRole] = useState<"buyer" | "seller">("buyer");
  const [selectedDealId, setSelectedDealId] = useState<string | null>(null);

  const { data: dealsData, isLoading, refetch } = useListDeals({ role, limit: 50 }, {
    query: { enabled: !!token }
  });

  const { data: dealDetail, isLoading: dealLoading } = useGetDeal(selectedDealId!, {
    query: { enabled: !!selectedDealId }
  });

  const deliverMut = useDeliverDeal();
  const confirmMut = useConfirmDeal();
  const disputeMut = useDisputeDeal();
  const reviewMut = useReviewDeal();

  const [deliveryData, setDeliveryData] = useState("");
  const [disputeReason, setDisputeReason] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewText, setReviewText] = useState("");

  const [actionState, setActionState] = useState<"none" | "deliver" | "dispute" | "review">("none");

  if (!token) {
    setLocation("/auth");
    return null;
  }

  const getStatusConfig = (status: string) => {
    switch(status) {
      case 'pending': return { color: 'bg-zinc-500/20 text-zinc-400', icon: Clock };
      case 'active': return { color: 'bg-blue-500/20 text-blue-400', icon: Clock };
      case 'delivered': return { color: 'bg-primary/20 text-primary', icon: Package };
      case 'completed': return { color: 'bg-green-500/20 text-green-500', icon: CheckCircle2 };
      case 'disputed': return { color: 'bg-destructive/20 text-destructive', icon: AlertCircle };
      case 'cancelled': return { color: 'bg-destructive/20 text-destructive', icon: AlertCircle };
      default: return { color: 'bg-secondary text-foreground', icon: Package };
    }
  };

  const handleDeliver = () => {
    if (!selectedDealId || !deliveryData.trim()) return;
    deliverMut.mutate({ id: selectedDealId, data: { deliveryData } }, {
      onSuccess: () => {
        toast({ title: "Delivery submitted" });
        setActionState("none");
        refetch();
        setSelectedDealId(null);
      },
      onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleConfirm = () => {
    if (!selectedDealId) return;
    confirmMut.mutate({ id: selectedDealId }, {
      onSuccess: () => {
        toast({ title: "Deal confirmed" });
        refetch();
        setSelectedDealId(null);
      },
      onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleDispute = () => {
    if (!selectedDealId || !disputeReason.trim()) return;
    disputeMut.mutate({ id: selectedDealId, data: { reason: disputeReason } }, {
      onSuccess: () => {
        toast({ title: "Dispute opened" });
        setActionState("none");
        refetch();
        setSelectedDealId(null);
      },
      onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleReview = () => {
    if (!selectedDealId) return;
    reviewMut.mutate({ id: selectedDealId, data: { rating: reviewRating, text: reviewText } }, {
      onSuccess: () => {
        toast({ title: "Review submitted" });
        setActionState("none");
        refetch();
        setSelectedDealId(null);
      },
      onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  return (
    <div className="flex flex-col min-h-full bg-background p-4 gap-4 pb-8">
      <h1 className="text-2xl font-bold">My Deals</h1>

      <Tabs defaultValue="purchases" onValueChange={(v) => setRole(v === 'purchases' ? 'buyer' : 'seller')}>
        <TabsList className="grid w-full grid-cols-2 bg-secondary h-12 p-1 rounded-xl mb-4">
          <TabsTrigger value="purchases" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Purchases</TabsTrigger>
          <TabsTrigger value="sales" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Sales</TabsTrigger>
        </TabsList>
        
        <div className="flex flex-col gap-3">
          {isLoading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-28 w-full rounded-xl" />
            ))
          ) : dealsData?.deals && dealsData.deals.length > 0 ? (
            dealsData.deals.map((deal) => {
              const statusCfg = getStatusConfig(deal.status);
              const StatusIcon = statusCfg.icon;
              const date = deal.createdAt ? format(new Date(deal.createdAt), 'MMM d, HH:mm') : '';
              
              return (
                <div 
                  key={deal.id} 
                  className="bg-card border border-border rounded-xl p-4 flex flex-col gap-3 cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => setSelectedDealId(deal.id)}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex flex-col gap-1">
                      <span className="text-xs text-muted-foreground font-mono">#{deal.dealNumber}</span>
                      <span className="font-bold text-sm line-clamp-1">{deal.product?.title || 'Unknown Product'}</span>
                    </div>
                    <Badge variant="outline" className={`border-none ${statusCfg.color} flex gap-1 items-center px-2 py-0.5 shrink-0`}>
                      <StatusIcon className="w-3 h-3" />
                      <span className="capitalize text-xs">{deal.status}</span>
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between mt-1">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{role === 'buyer' ? 'Seller' : 'Buyer'}</span>
                      <span className="text-sm font-medium">{role === 'buyer' ? deal.seller?.username : deal.buyer?.username}</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
                        {role === 'seller' ? 'You Receive' : 'Amount'}
                      </span>
                      <span className="text-base font-bold text-primary">
                        ${(role === 'seller' ? deal.sellerAmount : deal.amount)?.toFixed(2)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="text-[10px] text-muted-foreground text-right">{date}</div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 text-muted-foreground flex flex-col items-center gap-3 bg-secondary/30 rounded-xl">
              <Package className="w-12 h-12 opacity-20" />
              <p>No {role === 'buyer' ? 'purchases' : 'sales'} found</p>
            </div>
          )}
        </div>
      </Tabs>

      {/* Deal Detail Dialog */}
      <Dialog open={!!selectedDealId} onOpenChange={(open) => {
        if (!open) {
          setSelectedDealId(null);
          setActionState("none");
        }
      }}>
        <DialogContent className="sm:max-w-[400px] bg-card border-border max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Deal #{dealDetail?.dealNumber}</DialogTitle>
          </DialogHeader>

          {dealLoading || !dealDetail ? (
            <div className="flex flex-col gap-4 py-4">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <div className="flex flex-col gap-5 mt-2">
              {/* Status */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Status:</span>
                <Badge variant="outline" className={`border-none ${getStatusConfig(dealDetail.status).color} flex gap-1 items-center px-2 py-0.5`}>
                  {dealDetail.status.toUpperCase()}
                </Badge>
              </div>

              {/* Product */}
              <div className="bg-secondary rounded-xl p-3 flex flex-col gap-1">
                <span className="text-xs text-muted-foreground">Product</span>
                <span className="font-medium text-sm">{dealDetail.product?.title}</span>
              </div>

              {/* Financials */}
              <div className="flex justify-between bg-secondary/50 rounded-xl p-3">
                <div className="flex flex-col gap-1">
                  <span className="text-xs text-muted-foreground">Paid by Buyer</span>
                  <span className="font-bold">${dealDetail.amount?.toFixed(2)}</span>
                </div>
                <div className="flex flex-col gap-1 text-right">
                  <span className="text-xs text-muted-foreground">Seller Receives</span>
                  <span className="font-bold text-primary">${dealDetail.sellerAmount?.toFixed(2)}</span>
                </div>
              </div>

              {/* Delivery Data */}
              {(dealDetail.status === 'delivered' || dealDetail.status === 'completed') && dealDetail.deliveryData && (
                <div className="flex flex-col gap-2">
                  <span className="text-sm font-bold">Delivery Data</span>
                  <div className="bg-secondary p-3 rounded-xl font-mono text-sm break-all whitespace-pre-wrap border border-primary/20">
                    {dealDetail.deliveryData}
                  </div>
                </div>
              )}

              {/* Actions based on status and role */}
              <div className="flex flex-col gap-3 mt-4 pt-4 border-t border-border">
                {/* SELLER ACTIONS */}
                {role === 'seller' && dealDetail.status === 'active' && actionState === 'none' && (
                  <Button onClick={() => setActionState('deliver')} className="w-full">Deliver Items/Data</Button>
                )}

                {role === 'seller' && actionState === 'deliver' && (
                  <div className="flex flex-col gap-3">
                    <span className="text-sm font-bold">Enter Delivery Data</span>
                    <Textarea 
                      value={deliveryData} 
                      onChange={e => setDeliveryData(e.target.value)}
                      placeholder="Account details, keys, or download link..."
                      className="bg-secondary min-h-[100px] border-none"
                    />
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1" onClick={() => setActionState('none')}>Cancel</Button>
                      <Button className="flex-1" onClick={handleDeliver} disabled={deliverMut.isPending || !deliveryData.trim()}>Submit</Button>
                    </div>
                  </div>
                )}

                {/* BUYER ACTIONS */}
                {role === 'buyer' && dealDetail.status === 'delivered' && actionState === 'none' && (
                  <div className="flex flex-col gap-3">
                    <Button onClick={handleConfirm} className="w-full bg-green-500 hover:bg-green-600 text-white" disabled={confirmMut.isPending}>
                      Confirm Receipt
                    </Button>
                    <Button variant="outline" onClick={() => setActionState('dispute')} className="w-full text-destructive border-destructive/20 hover:bg-destructive/10">
                      Open Dispute
                    </Button>
                  </div>
                )}

                {role === 'buyer' && actionState === 'dispute' && (
                  <div className="flex flex-col gap-3">
                    <span className="text-sm font-bold text-destructive">Dispute Reason</span>
                    <Textarea 
                      value={disputeReason} 
                      onChange={e => setDisputeReason(e.target.value)}
                      placeholder="Explain what is wrong with the order..."
                      className="bg-secondary min-h-[100px] border-none"
                    />
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1" onClick={() => setActionState('none')}>Cancel</Button>
                      <Button variant="destructive" className="flex-1" onClick={handleDispute} disabled={disputeMut.isPending || !disputeReason.trim()}>Submit Dispute</Button>
                    </div>
                  </div>
                )}

                {/* REVIEW ACTION */}
                {role === 'buyer' && dealDetail.status === 'completed' && !dealDetail.buyerConfirmed /* Simplification, ideally backend tracks if reviewed */ && actionState === 'none' && (
                  <Button onClick={() => setActionState('review')} className="w-full" variant="outline">
                    <Star className="w-4 h-4 mr-2" /> Leave Review
                  </Button>
                )}

                {role === 'buyer' && actionState === 'review' && (
                  <div className="flex flex-col gap-3">
                    <span className="text-sm font-bold">Rate Seller</span>
                    <div className="flex gap-2 justify-center py-2">
                      {[1,2,3,4,5].map(star => (
                        <Star 
                          key={star} 
                          className={`w-8 h-8 cursor-pointer ${star <= reviewRating ? 'fill-primary text-primary' : 'text-muted-foreground opacity-30'}`}
                          onClick={() => setReviewRating(star)}
                        />
                      ))}
                    </div>
                    <Textarea 
                      value={reviewText} 
                      onChange={e => setReviewText(e.target.value)}
                      placeholder="Optional feedback..."
                      className="bg-secondary min-h-[80px] border-none"
                    />
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1" onClick={() => setActionState('none')}>Cancel</Button>
                      <Button className="flex-1" onClick={handleReview} disabled={reviewMut.isPending}>Submit Review</Button>
                    </div>
                  </div>
                )}

                {/* Chat button for everyone */}
                <Button variant="secondary" className="w-full" onClick={() => setLocation(`/messages/${role === 'buyer' ? dealDetail.sellerId : dealDetail.buyerId}`)}>
                  <MessageCircle className="w-4 h-4 mr-2" /> Chat with {role === 'buyer' ? 'Seller' : 'Buyer'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
