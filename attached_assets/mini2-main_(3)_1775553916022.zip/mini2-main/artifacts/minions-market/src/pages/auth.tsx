import { useState } from "react";
import { useLocation } from "wouter";
import { useLogin, useRegister } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";

export function Auth() {
  const [, setLocation] = useLocation();
  const { setToken } = useAuth();
  const { t } = useLang();
  const { toast } = useToast();
  const [tab, setTab] = useState<"login" | "register">("login");

  const loginMutation = useLogin();
  const registerMutation = useRegister();

  const [loginForm, setLoginForm] = useState({ username: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ username: "", password: "", firstName: "" });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ data: loginForm }, {
      onSuccess: (res) => {
        setToken(res.token);
        setLocation("/");
      },
      onError: (err: any) => {
        const msg = err?.data?.error || err?.message || t("error");
        toast({ title: msg, variant: "destructive" });
      },
    });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    registerMutation.mutate({ data: registerForm }, {
      onSuccess: (res) => {
        setToken(res.token);
        setLocation("/");
      },
      onError: (err: any) => {
        const msg = err?.data?.error || err?.message || t("error");
        toast({ title: msg, variant: "destructive" });
      },
    });
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-130px)] px-4">
      <div className="w-full max-w-sm flex flex-col gap-6">
        {/* Logo */}
        <div className="text-center">
          <h1 className="text-3xl font-black text-[#FFD600]">Minions.Market</h1>
          <p className="text-white/40 text-sm mt-1">
            {tab === "login"
              ? (t("loginTitle"))
              : (t("registerTitle"))}
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-[#1B1B1D] rounded-2xl p-1 gap-1">
          {(["login", "register"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setTab(v)}
              className={`flex-1 py-2.5 rounded-xl text-[15px] font-bold transition-all ${
                tab === v
                  ? "bg-[#FFD600] text-black"
                  : "text-white/40 hover:text-white/60"
              }`}
            >
              {v === "login" ? t("loginTitle") : t("registerTitle")}
            </button>
          ))}
        </div>

        {/* Login form */}
        {tab === "login" && (
          <form onSubmit={handleLogin} className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium text-white/60">{t("username")}</label>
              <input
                autoComplete="username"
                placeholder={t("username")}
                value={loginForm.username}
                onChange={(e) => setLoginForm(p => ({ ...p, username: e.target.value }))}
                className="w-full h-12 px-4 bg-[#1B1B1D] border border-white/5 rounded-xl text-white placeholder:text-white/25 outline-none focus:border-[#FFD600]/40 transition-colors"
                required
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium text-white/60">{t("password")}</label>
              <input
                type="password"
                autoComplete="current-password"
                placeholder={t("password")}
                value={loginForm.password}
                onChange={(e) => setLoginForm(p => ({ ...p, password: e.target.value }))}
                className="w-full h-12 px-4 bg-[#1B1B1D] border border-white/5 rounded-xl text-white placeholder:text-white/25 outline-none focus:border-[#FFD600]/40 transition-colors"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loginMutation.isPending}
              className="w-full h-12 bg-[#FFD600] text-black font-black text-base rounded-xl mt-2 disabled:opacity-50 transition-opacity active:scale-95"
            >
              {loginMutation.isPending ? "..." : t("loginBtn")}
            </button>
          </form>
        )}

        {/* Register form */}
        {tab === "register" && (
          <form onSubmit={handleRegister} className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium text-white/60">{t("username")}</label>
              <input
                autoComplete="username"
                placeholder="3–24 символа: a-z, 0-9, _"
                value={registerForm.username}
                onChange={(e) => setRegisterForm(p => ({ ...p, username: e.target.value }))}
                className="w-full h-12 px-4 bg-[#1B1B1D] border border-white/5 rounded-xl text-white placeholder:text-white/25 outline-none focus:border-[#FFD600]/40 transition-colors"
                required
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium text-white/60">{t("firstName")}</label>
              <input
                autoComplete="given-name"
                placeholder={t("firstName")}
                value={registerForm.firstName}
                onChange={(e) => setRegisterForm(p => ({ ...p, firstName: e.target.value }))}
                className="w-full h-12 px-4 bg-[#1B1B1D] border border-white/5 rounded-xl text-white placeholder:text-white/25 outline-none focus:border-[#FFD600]/40 transition-colors"
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium text-white/60">{t("password")}</label>
              <input
                type="password"
                autoComplete="new-password"
                placeholder={t("password")}
                value={registerForm.password}
                onChange={(e) => setRegisterForm(p => ({ ...p, password: e.target.value }))}
                className="w-full h-12 px-4 bg-[#1B1B1D] border border-white/5 rounded-xl text-white placeholder:text-white/25 outline-none focus:border-[#FFD600]/40 transition-colors"
                required
              />
            </div>
            <button
              type="submit"
              disabled={registerMutation.isPending}
              className="w-full h-12 bg-[#FFD600] text-black font-black text-base rounded-xl mt-2 disabled:opacity-50 transition-opacity active:scale-95"
            >
              {registerMutation.isPending ? "..." : t("registerBtn")}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
