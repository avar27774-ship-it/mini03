import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth";
import { LangProvider } from "@/lib/i18n";
import { Layout } from "@/components/layout";

// Pages
import NotFound from "@/pages/not-found";
import { Home } from "@/pages/home";
import { Auth } from "@/pages/auth";
import { Catalog } from "@/pages/catalog";
import { Product } from "@/pages/product";
import { Profile } from "@/pages/profile";
import { Sell } from "@/pages/sell";
import { Deals } from "@/pages/deals";
import { Wallet } from "@/pages/wallet";
import { Messages } from "@/pages/messages";
import { Settings } from "@/pages/settings";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/auth" component={Auth} />
        <Route path="/catalog" component={Catalog} />
        <Route path="/product/:id" component={Product} />
        <Route path="/profile" component={Profile} />
        <Route path="/profile/:id" component={Profile} />
        <Route path="/sell" component={Sell} />
        <Route path="/deals" component={Deals} />
        <Route path="/wallet" component={Wallet} />
        <Route path="/messages" component={Messages} />
        <Route path="/messages/:userId" component={Messages} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LangProvider>
        <AuthProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </LangProvider>
    </QueryClientProvider>
  );
}

export default App;
